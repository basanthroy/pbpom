__author__ = 'broy'

import MySQLdb
import logging
import pyhs2
import os

import sys
import time
import traceback


def main():
    print 'Inner main method'


    # rw_db_connect = MySQLdb.connect(table.read_write_mysql['host'],
    #                             utility.get_file_one_line(table.read_write_mysql['user']),
    #                             utility.get_file_one_line(table.read_write_mysql['passwd']),
    #                             rw_db)


    rw_db_connect = MySQLdb.connect('que2.dw.sc.gwallet.com',
                                'arteu',
                                'arteu1arteu',
                                'test_algo')
    rw_db_connect.autocommit(False)
    cursor = rw_db_connect.cursor()

    ro_db_connect = MySQLdb.connect('report1.dw.sc.gwallet.com',
                                    'arteu',
                                    'arteu1arteu',
                                    'radiumone_master')

    ro_db_connect.autocommit(False)
    cursor_ro = ro_db_connect.cursor()

    try:

        delete_old_data(cursor)
        copy_strategies_from_master(cursor, cursor_ro)


        # table.read_write_join_requests_table['name'] + ' ' + \


        select_pending_join_requests_statement = 'SELECT ' + \
                                                 'algo_id, ' + \
                                                 'MIN(create_ts) AS min_create_ts ' + \
                                                 'FROM ' + \
                                                 'PB_QUEUE ' + \
                                                 'WHERE status = "pending" ' + \
                                                 'GROUP BY algo_id ' + \
                                                 'ORDER BY min_create_ts ASC ' + \
                                                 'FOR UPDATE'

        logging.info('')
        # logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + select_pending_join_requests_statement)
        cursor.execute(select_pending_join_requests_statement)

        for algo_id_and_min_create_ts in cursor:
            algo_id_str = str(algo_id_and_min_create_ts[0])
            print 'algo_id_str=', algo_id_str

        print("Finished SQL, going to hive ...")

        dimension_predictions_count = 0
        dimension_predictions_to_join = []
        # ro_host = table.read_only_hive['host']

        # print('')
        # print(" Getting data from hive ...")

        # with pyhs2.connect(host='jobserver.dw.sc.gwallet.com',
        #                    user='bruderman',
        #                    password='brad',
        #                    port='10000',
        #                    authMechanism='PLAIN'
        #                    ) as conn:
        #     with conn.cursor() as cur:
        #         print('')
        #
        #         hiveql = 'SELECT * FROM adpred.arte_dimension_predictions WHERE algo_id = 1 limit 5'
        #
        #         # logging.info(' In host, ' + ro_host + ', executing the hql statement: ' +
        #         #              hiveql)
        #         cur.execute(hiveql)
        #         for i in cur.fetch():
        #             # print 'writing the data to the output file ...'
        #
        #             dimension_predictions_count += 1
        #             logging.debug('\t' + str(dimension_predictions_count) + '\t' + str(i))
        #             dimension_predictions_to_join.append(i)
        #             print ('i=', i)
        #
        #         cur.close()
        #         print('')

        # if len(dimension_predictions_to_join) == dimension_predictions_count:
        #     logging.info(' The total number of the dimension predictions TO JOIN is ' +
        #                  str(dimension_predictions_count))
        # else:
        #     logging.error(' ERROR: The total number of the dimension predictions TO JOIN is'
        #                   ' not matched with the count.')
        #     sys.exit(-1)

        copy_new_strats_to_old(cursor)
        # delete_old_data(cursor)

        rw_db_connect.commit()
    except:
        print('')
        print(' Going to rollback (i.e., release the lock)')
        rw_db_connect.rollback()  # Note: rollback (i.e., release the lock) if anything goes wrong
        # logging.error(traceback.format_exc())
        # update_join_request_status(rw_db, time.time(), algo_id_str, PENDING_STATUS,
        #                            ERROR_STATUS_PREFIX + str(sys.exc_info()[0]))
        # update_join_request_status(rw_db, time.time(), algo_id_str, PROCESSING_STATUS,
        #                            ERROR_STATUS_PREFIX + str(sys.exc_info()[0]))
    cursor.close()
    print('')
    # logging.info(' *** UNLOCK at ' + utility.get_current_time_up_to_second(time.time()))


def delete_old_data(cursor):
    try:
        delete_statement = 'delete from PB_STRATEGIES_CURRENT'
        num_rows_deleted = cursor.execute(delete_statement)
        print 'delete_old_data, number of rows deleted=', num_rows_deleted
    except:
        print 'exception=', traceback.format_exc()


def copy_strategies_from_master(cursor, cursor_ro):

    try:
        copy_strategies_statement = 'select strategy_id, baseline_bid, max_bid from STRATEGIES where bidding_engine_id = 3'
        insert_strategies_statement = 'insert into PB_STRATEGIES_CURRENT(strategy_id, baseline_bid, max_bid) VALUES (%s, %s, %s) '

        num_rows_selected = cursor_ro.execute(copy_strategies_statement)
        print 'copy_strategies_from_master, number of new strategies selected=', num_rows_selected
        rows = []
        for row in cursor_ro:
            rows.append(row)

        # print 'rows={}'.format(rows)
        num_rows_inserted = cursor.executemany(insert_strategies_statement, rows)
        print 'copy_strategies_from_master, number of new strategies inserted=', num_rows_inserted

    except:
        print 'exception=', traceback.format_exc()


def copy_new_strats_to_old(cursor):
    try:
        delete_previous_strats = 'DELETE FROM PB_STRATEGIES_PREVIOUS'
        copy_strats_statement = """insert into PB_STRATEGIES_PREVIOUS(strategy_id, baseline_bid, max_bid)
                                   SELECT strategy_id, baseline_bid, max_bid from PB_STRATEGIES_CURRENT
                                """
        num_rows_deleted = cursor.execute(delete_previous_strats)
        print 'copy_new_strats_to_old, number of rows deleted=', num_rows_deleted
        num_rows_copied = cursor.execute(copy_strats_statement)
        print 'copy_new_strats_to_old, number of rows copied=', num_rows_copied
    except:
        print 'exception=', traceback.format_exc()


if __name__ == '__main__':
    print 'main invoked'
    main();