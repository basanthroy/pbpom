__author__ = 'cliu'

import logging
import MySQLdb
import pyhs2
import os

import sys
import time
import traceback

from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import algo
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import common
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import period
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import table
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.job import enqueue
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import file
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import http
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import utility

PENDING_STATUS = "pending"
PROCESSING_STATUS = "processing"
COMPLETE_STATUS = "complete"
ERROR_STATUS_PREFIX = "error: "


def get_strategies_to_join(db):
    logging.info('')

    select_strategies_to_join_statement = 'SELECT ' + \
                                          table.read_write_strategies_table['columns'] + ' ' + \
                                          'FROM ' + \
                                          table.read_write_strategies_table['tmp_name']
    logging.info(' In db, ' + db + ', executing the sql statement: ' + select_strategies_to_join_statement)
    return utility.run_sql_with_db(table.read_write_mysql['host'],
                                   utility.get_file_one_line(table.read_write_mysql['user']),
                                   utility.get_file_one_line(table.read_write_mysql['passwd']),
                                   db,
                                   select_strategies_to_join_statement)


def get_select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement(
        algo_id_in_pending_join_request_str):
    return 'SELECT * FROM adpred.arte_dimension_predictions WHERE algo_id = ' + algo_id_in_pending_join_request_str #+ \
           #' limit 5'  # TODO: comment it out later ...


def update_join_request_status_given_cursor(db, cursor_obj, epoch_time, algo_id_string, src_status_str, dst_status_str):
    logging.info('')
    current_time_up_to_hundredth_of_a_second = utility.get_current_time_up_to_hundredth_of_a_second(epoch_time)
    update_status_statement = 'UPDATE ' + \
                              table.read_write_join_requests_table['name'] + ' ' + \
                              'SET ' + \
                              'update_ts = ' + current_time_up_to_hundredth_of_a_second + ', ' + \
                              'status = "' + dst_status_str + '" ' + \
                              'WHERE ' + \
                              'algo_id = ' + algo_id_string + ' ' + \
                              'AND ' + \
                              'status = "' + src_status_str + '"'
    logging.info(' Setting the status from "' + src_status_str + '" to "' + dst_status_str + '" through the following:')
    logging.info(' In db, ' + db + ', executing the sql statement: ' + update_status_statement)
    cursor_obj.execute(update_status_statement)


def update_join_request_status(db, epoch_time, algo_id_string, src_status_str, dst_status_str):
    logging.info('')
    current_time_up_to_hundredth_of_a_second = utility.get_current_time_up_to_hundredth_of_a_second(epoch_time)
    update_status_statement = 'UPDATE ' + \
                              table.read_write_join_requests_table['name'] + ' ' + \
                              'SET ' + \
                              'update_ts = ' + current_time_up_to_hundredth_of_a_second + ', ' + \
                              'status = "' + dst_status_str + '" ' + \
                              'WHERE ' + \
                              'algo_id = ' + algo_id_string + ' ' + \
                              'AND ' + \
                              'status = "' + src_status_str + '"'
    logging.info(' Setting the status from "' + src_status_str + '" to "' + dst_status_str + '" through the following:')
    logging.info(' In db, ' + db + ', executing the sql statement: ' + update_status_statement)

    utility.run_sql_with_db_with_commit(table.read_write_mysql['host'],
                                        utility.get_file_one_line(table.read_write_mysql['user']),
                                        utility.get_file_one_line(table.read_write_mysql['passwd']),
                                        db,
                                        update_status_statement)


def run_mapping_func(mapping_function_abs_path_str,
                     input_fsv_abs_path_str,
                     output_tsv_abs_path_str,
                     output_log_abs_path_str):
    os.system(common.settings['python'] + ' ' +
              mapping_function_abs_path_str + ' ' +
              input_fsv_abs_path_str + ' ' +
              output_tsv_abs_path_str + ' ' +
              output_log_abs_path_str)


def remove_the_temporary_folder_for_holding_the_resulting_algorithm_directory(
        temporary_login_and_host_str,
        temporary_folder_for_holding_the_resulting_algorithm_directory_abs_path_str):
    logging.info("TODO: ")
    os.system("ssh " +
              temporary_login_and_host_str + ' ' +
              "'"
              "rm -rf " +
              temporary_folder_for_holding_the_resulting_algorithm_directory_abs_path_str +
              "'")                                #TODO: os.system("rm -rf " + tmp_folder_path)

    #print "ssh " + template_login_and_host + ' ' + "'" + "rm -rf " + temporary_folder_for_holding_the_resulting_algorithm_directory_abs_path + "'"


def create_the_temporary_folder_for_holding_the_resulting_algorithm_directory(
        template_login_and_host_str,
        temporary_folder_for_holding_the_resulting_algorithm_directory_abs_path_str):
    os.system("ssh " +
              template_login_and_host_str + ' ' +
              "'"
              "mkdir -p " +
              temporary_folder_for_holding_the_resulting_algorithm_directory_abs_path_str +
              "'")


def copy_algorithm_directory_template_to_temporary_folder_to_create_resulting_algorithm_dir(# TODO: modify the method so that temp can be other machine ...
        template_login_and_host_str,
        template_folder_for_holding_the_algorithm_directory_templates_abs_path_str, algo_dir_rel_path_str,
        temporary_folder_for_holding_the_resulting_algorithm_directory_abs_path_str, algo_dir_rel_path_str2):
    os.system("ssh " +
              template_login_and_host_str + ' ' +
              "'"
              "cp -r -p " +
              template_folder_for_holding_the_algorithm_directory_templates_abs_path_str + algo_dir_rel_path_str +
              " " +
              temporary_folder_for_holding_the_resulting_algorithm_directory_abs_path_str + algo_dir_rel_path_str2 +
              "'")


def provide_data_to_resulting_algorithm_directory_in_the_temporary_folder(
        output_tsv_abs_path_str,
        the_resulting_algorithm_directory_data_folder_abs_path_str):# TODO: after moving the data to hdfs ... AND NEED TO WORK STILL
    os.system("scp " + output_tsv_abs_path_str + ' ' +
              the_resulting_algorithm_directory_data_folder_abs_path_str)


def deploy_the_resulting_algorithm_directory_in_the_prod_machine(
        resulting_algorithm_directory_abs_path_str):






    logging.info("ssh " +
              common.settings['test_or_prod']['deploy_login'] + '@' +
              common.settings['test_or_prod']['deploy_host'] + " '" +
              "sudo -i -u recu " +
              "scp -r " +
              common.settings['app_login'] + '@' +
              common.settings['app_host'] + ':' +
              resulting_algorithm_directory_abs_path_str + " " +
              common.settings['test_or_prod']['deploy_arte_home'] +
              common.settings['to_add_rel_path'] +
              #"records/" +
              "'")

    os.system("ssh " +
              common.settings['test_or_prod']['deploy_login'] + '@' +
              common.settings['test_or_prod']['deploy_host'] + " '" +
              "sudo -i -u recu " +
              "scp -r " +
              common.settings['app_login'] + '@' +
              common.settings['app_host'] + ':' +
              resulting_algorithm_directory_abs_path_str + " " +
              common.settings['test_or_prod']['deploy_arte_home'] +
              common.settings['to_add_rel_path'] +
              #"records/" +
              "'")




def deploy_the_resulting_algorithm_directory_in_the_test_machine(
        resulting_algorithm_directory_abs_path_str):
    logging.info("scp -r " + resulting_algorithm_directory_abs_path_str + ' ' +
              common.settings['test_or_prod']['deploy_login'] + '@' +
              common.settings['test_or_prod']['deploy_host'] + ':' +
              common.settings['test_or_prod']['deploy_arte_home'] +
              common.settings['to_add_rel_path'])
    os.system("scp -r " + resulting_algorithm_directory_abs_path_str + ' ' +
              common.settings['test_or_prod']['deploy_login'] + '@' +
              common.settings['test_or_prod']['deploy_host'] + ':' +
              common.settings['test_or_prod']['deploy_arte_home'] +
              common.settings['to_add_rel_path'])


if __name__ == '__main__':

    is_infinite_loop = False
    for arg in sys.argv:
        if arg == '-loop':
            is_infinite_loop = True
            break
    run_yet = False
    while (not run_yet):
        run_yet = True

        logging.basicConfig(#filename=common.dequeue_log['file'],
                            level=common.dequeue_log['level'])
        logging.info('')

        start_time = time.time()
        logging.info(' The dequeue job starts at ' + time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time)))


        enqueue.init()

        # TODO: update the status' time.time() to get_current_time_up_to_the_smallest_time ...

        #print time.strftime('%Y%m%d', time.localtime(time.time()))

        ################################################################################
        # by default, the test db is used unless one specify the prod db through -prod #
        ################################################################################

        is_prod_machine = False
        for arg in sys.argv:
            if arg == '-prod':
                is_prod_machine = True
                break

        if is_prod_machine:
            common.settings['test_or_prod'] = common.prod
            table.read_write_mysql['test_or_prod'] = table.prod
            logging.info(' This is for the production machine.')
        else:
            logging.info(' This is for the test machine.')
        logging.info(' Hence, the database, ' + table.read_write_mysql['test_or_prod']['db'] + ', in ' +
                     table.read_write_mysql['host'] + ' is used.')

        #################################################################################################################
        # by default, deploy to the test machine unless one specify the prod machine through -h followed by the ip addr #
        #################################################################################################################

        ip_addr = False
        machine_ip_addr = common.settings['test_or_prod']['deploy_host']
        for arg in sys.argv:
            if ip_addr:
                machine_ip_addr = arg
                break
            if arg == '-h':
                ip_addr = True
        common.settings['test_or_prod']['deploy_host'] = machine_ip_addr
        logging.info(' Also, the arte server deployed in ' + common.settings['test_or_prod']['deploy_host'] + ' is used.')

        ########################################
        # about to set up the MySQL connection #
        ########################################

        logging.info('')
        logging.info(' Setting up the connection to the database server ...')

        rw_db = table.read_write_mysql['test_or_prod']['db']
        rw_db_connect = MySQLdb.connect(table.read_write_mysql['host'],
                             utility.get_file_one_line(table.read_write_mysql['user']),
                             utility.get_file_one_line(table.read_write_mysql['passwd']),
                             rw_db)
        rw_db_connect.autocommit(False)
        cursor = rw_db_connect.cursor()

        algo_ids_in_pending_join_requests = []



        #
        # set them when in sync ...
        #
        current_epoch_time = time.time()
        dt = utility.get_current_time_up_to_date(current_epoch_time)
        current_timestamp_up_to_hundredth_of_a_second = utility.get_current_time_up_to_hundredth_of_a_second(current_epoch_time)
        #current_timestamp_dir_name = current_timestamp_up_to_hundredth_of_a_second  # utility.get_current_time_prefix(current_epoch_time)

        logging.info('')
        logging.info(' ***   LOCK at ' + utility.get_current_time_up_to_second(time.time()))
        try:
            select_pending_join_requests_statement = 'SELECT ' + \
                                                     'algo_id, ' + \
                                                     'MIN(create_ts) AS min_create_ts ' + \
                                                     'FROM ' + \
                                                     table.read_write_join_requests_table['name'] + ' ' + \
                                                     'WHERE status = "pending" ' + \
                                                     'GROUP BY algo_id ' + \
                                                     'ORDER BY min_create_ts ASC ' + \
                                                     'FOR UPDATE'
            logging.info('')
            logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + select_pending_join_requests_statement)
            cursor.execute(select_pending_join_requests_statement)






            ############################################################################################################
            # CHANGE PENDING TO PROCESSING #############################################################################
            ############################################################################################################

            #timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log = current_timestamp_dir_name
            #current_timestamp_up_to_hundredth_of_a_second
            # current_timestamp_prefix

            for algo_id_and_min_create_ts in cursor:
                algo_id_str = str(algo_id_and_min_create_ts[0])
                min_create_ts_str = str(algo_id_and_min_create_ts[1])
                logging.info('')
                logging.info(' The earliest time that Algorithm ' + algo_id_str +
                             ' \twas requested and still pending is at ' + min_create_ts_str)
                algo_ids_in_pending_join_requests.append(algo_id_str)

                update_join_request_status_given_cursor(rw_db, cursor, time.time(), algo_id_str,
                                                        PENDING_STATUS, PROCESSING_STATUS)

                # algo_dir_to_upload = algo.get[algo_id_str]['algo_dir_rel_path']
                # logging.info(' The Algorithm ' + algo_id_str + ' is mapped to ' + algo_dir_to_upload)
                # timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log += ',' + algo_dir_to_upload

            # http_server_target_dir_path = common.upload['server'] + \
            #                               common.upload['arte_dir_abs_path'] + \
            #                               common.settings['test_or_prod']['target_folder_rel_path']
            # http_server_to_add_log_path = http_server_target_dir_path + \
            #                               common.upload['to_add_log_file_rel_path']
            #
            # logging.info('')
            # logging.info(' Later, going to the following to ' + http_server_to_add_log_path)
            # logging.info('')
            # logging.info(' Prepend to log this: ' + timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log)
            # logging.info('')
            #
            # local_to_add_log_path = http.download(http_server_to_add_log_path)
            # if file.contain(local_to_add_log_path, '404'):
            #     file.empty(local_to_add_log_path)
            # file.prepend(local_to_add_log_path, timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log)



            #
            #
            # prepend when in sync ...
            #
            # local_log_file = common.settings['test_or_prod']['target_folder_rel_path'][:-1]+'_'+common.upload['log_file']
            # logging.info('curl -o ' + local_log_file + ' ' + http_server_log_file_path)
            # os.system('curl -o ' + local_log_file + ' ' + http_server_log_file_path)






            #logging.info("http_server_log_file_path: " + http_server_log_file_path)
            #os.system('curl -O ' + http_server_log_file_path)


            # curl -O http://jobserver2.dw.sc.gwallet.com/arte/fwk/algo/toAdd/upload.log
            # TODO: keep the past 10k records in log ...
            # TODO: download
            # TODO: opposite of append ... prepend ?
            # TODO: upload





            logging.info('')
            logging.info(' Going to commit (i.e., release the lock)')
            rw_db_connect.commit()  # Note: commit (i.e., release the lock) right after select for update
        except:
            logging.info('')
            logging.info(' Going to rollback (i.e., release the lock)')
            rw_db_connect.rollback()  # Note: rollback (i.e., release the lock) if anything goes wrong
            logging.error(traceback.format_exc())
            update_join_request_status(rw_db, time.time(), algo_id_str, PENDING_STATUS,
                                       ERROR_STATUS_PREFIX + str(sys.exc_info()[0]))
            update_join_request_status(rw_db, time.time(), algo_id_str, PROCESSING_STATUS,
                                       ERROR_STATUS_PREFIX + str(sys.exc_info()[0]))
        cursor.close()
        logging.info('')
        logging.info(' *** UNLOCK at ' + utility.get_current_time_up_to_second(time.time()))




        timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log = \
            current_timestamp_up_to_hundredth_of_a_second

        http_server_target_dir_path = common.http['server'] + \
                                      common.http['arte_dir_abs_path'] + \
                                      common.settings['test_or_prod']['target_folder_rel_path']



        number_of_valid_algo_ids = 0;

        try:

            logging.info('')
            logging.info(' The total number of the pending join requests that need to be processed is ' +
                         str(len(algo_ids_in_pending_join_requests)) + '.')

            if len(algo_ids_in_pending_join_requests) > 0:
                strategies_to_join = get_strategies_to_join(rw_db)
                logging.info('')
                logging.info(' The total number of the strategies TO JOIN is ' +
                             str(len(strategies_to_join)) + '.')

                #
                # Note: Since the join is done here, the scalability is determined by the size of the following collections:
                #
                #       strategy_id_and_algo_id_to_join_______is_mapped_to_______arte_min_bid_and_arte_max_bid
                #       &
                #       arte_dimension_predictions  # TODO: rename to join something ...
                #
                strategy_id_and_algo_id_to_join______is_mapped_to______arte_min_bid_and_arte_max_bid = {}
                for strategy_to_join in strategies_to_join:
                    strategy_id_and_algo_id_to_join______is_mapped_to______arte_min_bid_and_arte_max_bid[
                        str(strategy_to_join[0]) + common.delimit + str(strategy_to_join[3])] = \
                        str(strategy_to_join[2]) + common.delimit + str(strategy_to_join[1])
                    logging.debug(' ' + str(strategy_to_join[0]) + ',' + str(strategy_to_join[3]) + ' -> ' + \
                                  str(strategy_to_join[2]) + ',' + str(strategy_to_join[1]))








                for algo_id_in_pending_join_request in algo_ids_in_pending_join_requests:
                    logging.info('')
                    logging.info(' ********** Processing the join request for algorithm ' + algo_id_in_pending_join_request)


                    if utility.does_represent_int(algo_id_in_pending_join_request):
                        logging.info(" It's a integer.")
                        if enqueue.is_valid_algo_id(algo_id_in_pending_join_request):
                            logging.info(" It's a valid algorithm id.")
                            logging.info(" The algorithm id, " + arg + ", is going to be dequeue-ed SUCCESSFULLY :)")
                            number_of_valid_algo_ids += 1
                            if is_prod_machine and int(algo_id_in_pending_join_request) >= 900 and int(algo_id_in_pending_join_request) <= 999 :
                                update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                    PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                    '900 level algo id is not allowed in the production machine.')
                                continue
                        else:
                            logging.info(" It's NOT a valid algorithm id.")
                            logging.info(" The algorithm id, " + algo_id_in_pending_join_request + ", FAILED to be dequeue-ed :(")
                            update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                               PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                               algo_id_in_pending_join_request +
                               " is not a valid algo id.")
                            continue
                    else:
                        logging.info(" It's NOT a integer.")
                        logging.info(" The algorithm id, " + algo_id_in_pending_join_request +
                                     ", FAILED to be dequeue-ed :(")
                        update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                               PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                               algo_id_in_pending_join_request +
                               " is not an integer.")
                        continue




                    algo_dir_rel_path = algo.get[algo_id_in_pending_join_request]['algo_dir_rel_path']

                    select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement = \
                        get_select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement(
                        algo_id_in_pending_join_request)

                    dimension_predictions_count = 0
                    dimension_predictions_to_join = []
                    ro_host = table.read_only_hive['host']

                    logging.info('')
                    logging.info(" Getting data from hive ...")

                    with pyhs2.connect(host=ro_host,
                                       user=utility.get_file_one_line(table.read_only_hive['user']),
                                       password=utility.get_file_one_line(table.read_only_hive['passwd']),
                                       port=table.read_only_hive['port'],
                                       authMechanism=table.read_only_hive['authMechanism']
                                      ) as conn:
                        with conn.cursor() as cur:

                            logging.info('')
                            logging.info(' In host, ' + ro_host + ', executing the hql statement: ' +
                                         select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement)
                            cur.execute(select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement)
                            for i in cur.fetch():

                                #print 'writing the data to the output file ...'

                                dimension_predictions_count += 1
                                logging.debug('\t' + str(dimension_predictions_count) + '\t' + str(i))
                                dimension_predictions_to_join.append(i)

                            cur.close()
                            logging.info('')

                    if len(dimension_predictions_to_join) == dimension_predictions_count:
                        logging.info(' The total number of the dimension predictions TO JOIN is ' +
                                     str(dimension_predictions_count))
                    else:
                        logging.error(' ERROR: The total number of the dimension predictions TO JOIN is'
                                      ' not matched with the count.')
                        sys.exit(-1)

                    logging.info('')
                    logging.info(' ***************************************************************** About time to join'
                                 ' radiumone_master.STRATEGIES(' + str(len(strategies_to_join)) + ') with'
                                 ' adpred.arte_dimension_predictions(' + str(dimension_predictions_count) + ').')


                    target_dir_abs_path_in_hdfs = common.settings['model_folder_path_in_hdfs'] + \
                                                  common.settings['test_or_prod']['target_folder_rel_path'] #+ \
                                                  #algo_dir_rel_path

                    ########################################################################################################
                    # HADOOP DISTRIBUTED FILE SYTEM ########################################################################
                    ########################################################################################################

                    logging.info('')


                    # function_folder_abs_path_in_hdfs = common.settings['model_folder_path_in_hdfs'] + \
                    #                                    algo_dir_rel_path + \
                    #                                    common.settings['test_or_prod']['target_folder_rel_path'] + \
                    #                                    common.settings['func_folder']

                    function_folder_abs_path_in_hdfs = target_dir_abs_path_in_hdfs + \
                                                       common.settings['func_folder'] + \
                                                       'algo_id=' + \
                                                       algo_id_in_pending_join_request + \
                                                       '/'



                    logging.info(' The newly created folder for mapping function in hdfs is ' + function_folder_abs_path_in_hdfs)

                    mapping_function_abs_path_in_hdfs = function_folder_abs_path_in_hdfs + \
                                                        algo.get[algo_id_in_pending_join_request]['mapping_func']
                    logging.info(' The mapping function                          in hdfs is ' + mapping_function_abs_path_in_hdfs)

                    # timestamp_folder_abs_path_for_log_in_hdfs = common.settings['model_folder_path_in_hdfs'] + \
                    #                                             algo_dir_rel_path + \
                    #                                             common.settings['test_or_prod']['target_folder_rel_path'] + \
                    #                                             common.settings['log_folder'] + \
                    #                                             'algo_id=' + algo_id_in_pending_join_request + '/' + \
                    #                                             'dt=' + dt + '/' #+ \
                    #                                             #current_timestamp_up_to_hundredth_of_a_second + '/'


                    timestamp_folder_abs_path_for_log_in_hdfs = target_dir_abs_path_in_hdfs + \
                                                                common.settings['log_folder'] + \
                                                                'algo_id=' + algo_id_in_pending_join_request + '/' + \
                                                                'dt=' + dt + '/' #+ \
                                                                #current_timestamp_up_to_hundredth_of_a_second + '/'




                    logging.info(' The newly created folder for log              in hdfs is ' + timestamp_folder_abs_path_for_log_in_hdfs)
                    # TODO: Alter table through hive to create directory structure in hdfs




                    output_log_abs_path_in_hdfs = timestamp_folder_abs_path_for_log_in_hdfs + current_timestamp_up_to_hundredth_of_a_second + '_' + common.settings['log_file']
                    logging.info(' The output_log.json                           in hdfs is ' + output_log_abs_path_in_hdfs)






                    # timestamp_folder_abs_path_for_input_in_hdfs = common.settings['model_folder_path_in_hdfs'] + \
                    #                                               algo_dir_rel_path + \
                    #                                               common.settings['test_or_prod']['target_folder_rel_path'] + \
                    #                                               common.settings['input_folder'] + \
                    #                                               'algo_id=' + algo_id_in_pending_join_request + '/' + \
                    #                                               'dt=' + dt + '/' #+ \
                    #                                               #current_timestamp_up_to_hundredth_of_a_second + '/'

                    timestamp_folder_abs_path_for_input_in_hdfs = target_dir_abs_path_in_hdfs + \
                                                                  common.settings['input_folder'] + \
                                                                  'algo_id=' + algo_id_in_pending_join_request + '/' + \
                                                                  'dt=' + dt + '/' #+ \
                                                                  #current_timestamp_up_to_hundredth_of_a_second + '/'



                    logging.info(' The newly created folder for input            in hdfs is ' + timestamp_folder_abs_path_for_input_in_hdfs)
                    # TODO: Alter table through hive to create directory structure in hdfs

                    input_fsv_abs_path_in_hdfs = timestamp_folder_abs_path_for_input_in_hdfs + current_timestamp_up_to_hundredth_of_a_second + '_' + common.settings['input_file']
                    logging.info(' The input.fsv                                 in hdfs is ' + input_fsv_abs_path_in_hdfs)

                    # timestamp_folder_abs_path_for_output_in_hdfs = common.settings['model_folder_path_in_hdfs'] + \
                    #                                                algo_dir_rel_path + \
                    #                                                common.settings['test_or_prod']['target_folder_rel_path'] + \
                    #                                                common.settings['output_folder'] + \
                    #                                                'algo_id=' + algo_id_in_pending_join_request + '/' + \
                    #                                                'dt=' + dt + '/' #+ \
                    #                                                #current_timestamp_up_to_hundredth_of_a_second + '/'

                    timestamp_folder_abs_path_for_output_in_hdfs = target_dir_abs_path_in_hdfs + \
                                                                   common.settings['output_folder'] + \
                                                                   'algo_id=' + algo_id_in_pending_join_request + '/' + \
                                                                   'dt=' + dt + '/' #+ \
                                                                   #current_timestamp_up_to_hundredth_of_a_second + '/'





                    logging.info(' The newly created folder for output           in hdfs is ' + timestamp_folder_abs_path_for_output_in_hdfs)
                    # TODO: Alter table through hive to create directory structure in hdfs

                    output_tsv_abs_path_in_hdfs = timestamp_folder_abs_path_for_output_in_hdfs + current_timestamp_up_to_hundredth_of_a_second + '_' + common.settings['output_file']
                    logging.info(' The output.tsv                                in hdfs is ' + output_tsv_abs_path_in_hdfs)
                    #
                    ##
                    ###
                    ####
                    ###
                    ##
                    #



                    #
                    ##
                    ###
                    ########################################################################################################


                    os.system("hadoop fs -mkdir -p " + timestamp_folder_abs_path_for_log_in_hdfs)
                    logging.info("hadoop fs -mkdir -p " + timestamp_folder_abs_path_for_log_in_hdfs)  # TODO:

                    os.system("hadoop fs -mkdir -p " + timestamp_folder_abs_path_for_input_in_hdfs)
                    logging.info("hadoop fs -mkdir -p " + timestamp_folder_abs_path_for_input_in_hdfs)  # TODO:

                    os.system("hadoop fs -mkdir -p " + timestamp_folder_abs_path_for_output_in_hdfs)
                    logging.info("hadoop fs -mkdir -p " + timestamp_folder_abs_path_for_output_in_hdfs)  # TODO:

                    target_dir_abs_path_in_fs = common.settings['tmp_folder_path_in_fs'] + \
                                                common.settings['test_or_prod']['target_folder_rel_path'] #+ \
                                                #algo_dir_rel_path

                    os.system("rm -rf " + target_dir_abs_path_in_fs)  # note: optional
                    logging.info("rm -rf " + target_dir_abs_path_in_fs)  # TODO:



                    ########################################################################################################
                    # LOCAL FILE SYSTEM ####################################################################################
                    ########################################################################################################

                    logging.info('')
                    # function_folder_abs_path_in_fs = common.settings['tmp_folder_path_in_fs'] + \
                    #                                  algo_dir_rel_path + \
                    #                                  common.settings['test_or_prod']['target_folder_rel_path'] + \
                    #                                  common.settings['func_folder']

                    function_folder_abs_path_in_fs = target_dir_abs_path_in_fs + \
                                                     common.settings['func_folder'] + \
                                                     'algo_id=' + \
                                                     algo_id_in_pending_join_request + \
                                                     '/'


                    logging.info(' The newly created folder for mapping function in   fs is ' + function_folder_abs_path_in_fs)
                    utility.create_folder_if_not_exists(function_folder_abs_path_in_fs)

                    mapping_function_abs_path_in_fs = function_folder_abs_path_in_fs + \
                                                      current_timestamp_up_to_hundredth_of_a_second + \
                                                      '_' + \
                                                      algo.get[algo_id_in_pending_join_request]['mapping_func']
                    logging.info(' The mapping function                          in   fs is ' + mapping_function_abs_path_in_fs)

                    timestamp_folder_abs_path_for_log_in_fs = target_dir_abs_path_in_fs + \
                                                              common.settings['log_folder'] + \
                                                              'algo_id=' + algo_id_in_pending_join_request + '/' + \
                                                              'dt=' + dt + '/' #+ \
                                                              #dt + '/' + \
                                                              #current_timestamp_up_to_hundredth_of_a_second + '/'

                    logging.info(' The newly created folder for log              in   fs is ' + timestamp_folder_abs_path_for_log_in_fs)
                    utility.create_folder_if_not_exists(timestamp_folder_abs_path_for_log_in_fs)

                    output_log_abs_path_in_fs = timestamp_folder_abs_path_for_log_in_fs + current_timestamp_up_to_hundredth_of_a_second + '_' + common.settings['log_file']
                    logging.info(' The output_log.json                           in   fs is ' + output_log_abs_path_in_fs)





                    timestamp_folder_abs_path_for_input_in_fs = target_dir_abs_path_in_fs + \
                                                               common.settings['input_folder'] + \
                                                               'algo_id=' + algo_id_in_pending_join_request + '/' + \
                                                               'dt=' + dt + '/' #+ \
                                                               #dt + '/' + current_timestamp_up_to_hundredth_of_a_second + '/'
                    logging.info(' The newly created folder for input            in   fs is ' + timestamp_folder_abs_path_for_input_in_fs)
                    utility.create_folder_if_not_exists(timestamp_folder_abs_path_for_input_in_fs)

                    input_fsv_abs_path_in_fs = timestamp_folder_abs_path_for_input_in_fs + current_timestamp_up_to_hundredth_of_a_second + '_' + common.settings['input_file']
                    logging.info(' The input.fsv                                 in   fs is ' + input_fsv_abs_path_in_fs)

                    timestamp_folder_abs_path_for_output_in_fs = target_dir_abs_path_in_fs + \
                                                               common.settings['output_folder'] + \
                                                               'algo_id=' + algo_id_in_pending_join_request + '/' + \
                                                               'dt=' + dt + '/' #+ \
                                                               #dt + '/' + current_timestamp_up_to_hundredth_of_a_second + '/'
                    logging.info(' The newly created folder for output           in   fs is ' + timestamp_folder_abs_path_for_output_in_fs)
                    utility.create_folder_if_not_exists(timestamp_folder_abs_path_for_output_in_fs)

                    output_tsv_abs_path_in_fs = timestamp_folder_abs_path_for_output_in_fs + current_timestamp_up_to_hundredth_of_a_second + '_' + common.settings['output_file']
                    logging.info(' The output.tsv                                in   fs is ' + output_tsv_abs_path_in_fs)

                    #
                    ##
                    ###
                    ####
                    ###
                    ##
                    #




                    #
                    ##
                    ###
                    ########################################################################################################

                    if utility.does_file_exist(mapping_function_abs_path_in_fs):
                        os.system("rm " + mapping_function_abs_path_in_fs)  # note: optional
                        logging.info("rm " + mapping_function_abs_path_in_fs)  # TODO:

                    os.system("hadoop fs -copyToLocal " + mapping_function_abs_path_in_hdfs + " " + mapping_function_abs_path_in_fs)
                    logging.info("hadoop fs -copyToLocal " + mapping_function_abs_path_in_hdfs + " " + mapping_function_abs_path_in_fs)

                    input_file_writer = open(input_fsv_abs_path_in_fs, 'w')

                    is_file_empty = True
                    line_counter = 0
                    for dimension_prediction_to_join in dimension_predictions_to_join:
                        strategy_id = str(dimension_prediction_to_join[0])
                        dimension_value_structs = dimension_prediction_to_join[1]
                        probability_score = str(dimension_prediction_to_join[2])
                        if algo_id_in_pending_join_request != dimension_prediction_to_join[3]:
                            sys.exit(-1)
                        one_line = strategy_id + \
                                   common.delimit + algo_id_in_pending_join_request + \
                                   common.delimit + dimension_value_structs + \
                                   common.delimit + probability_score + \
                                   common.delimit + \
                                   strategy_id_and_algo_id_to_join______is_mapped_to______arte_min_bid_and_arte_max_bid[
                                       strategy_id + common.delimit + algo_id_in_pending_join_request] + \
                                   common.delimit + dt + \
                                   common.delimit + current_timestamp_up_to_hundredth_of_a_second + '\n'
                                   #
                                   # Note: The KeyError may be due to
                                   # 1. an inexistent strategy_id ? or
                                   # 2. min_bid is not set ? (the min_bid and max_bid must be set) or
                                   # 3. ... ? or (still triage this issue)
                                   # e.g., '552211\x011'
                        line_counter += 1
                        if is_file_empty:
                            is_file_empty = False
                        input_file_writer.write(one_line) # TODO: append ??? before for loop, need to be empty ...  yes, need to do that ....
                    input_file_writer.close()











                    if utility.does_file_exist(mapping_function_abs_path_in_fs):
                        if utility.does_file_exist(input_fsv_abs_path_in_fs):
                            if not is_file_empty:

                                # TODO: Task #1.
                                #
                                # TODO: remove everything in tmp
                                # TODO: put input in temp, too.
                                # TODO: hadoop fs -copyToLocal /user/arteu/algo/algo_dimensionPlusOne/func/arte_bid_price_mapping.py /home/arteu/tmp/
                                # TODO: run it ...
                                # TODO: now, output and log is in tmep
                                # TODO: move everything to hdfs.



                                # TODO: input & output & log should be in the hdfs of arteu user !!!
                                # TODO: moduleize the following 3 ....

                                # TODO: run_the_mapping_function_to_get_the_output_tsv_file_for_arte_to_load

                                print 'begin mapping_func'


                                run_mapping_func(mapping_function_abs_path_in_fs, input_fsv_abs_path_in_fs, output_tsv_abs_path_in_fs, output_log_abs_path_in_fs)

                                # os.system("python " +
                                #           mapping_function_abs_path + ' ' +
                                #           input_fsv_abs_path + ' ' +
                                #           output_tsv_abs_path + ' ' +
                                #           output_tsv_abs_path)
                                print 'end   mapping_func'


                                os.system("hadoop fs -copyFromLocal " + output_log_abs_path_in_fs + " " + timestamp_folder_abs_path_for_log_in_hdfs)
                                logging.info("hadoop fs -copyFromLocal " + output_log_abs_path_in_fs + " " + timestamp_folder_abs_path_for_log_in_hdfs)  # TODO:


                                os.system("hadoop fs -copyFromLocal " + input_fsv_abs_path_in_fs + "* " + timestamp_folder_abs_path_for_input_in_hdfs)
                                logging.info("hadoop fs -copyFromLocal " + input_fsv_abs_path_in_fs + " " + timestamp_folder_abs_path_for_input_in_hdfs)  # TODO:


                                os.system("hadoop fs -copyFromLocal " + output_tsv_abs_path_in_fs + "* " + timestamp_folder_abs_path_for_output_in_hdfs)
                                logging.info("hadoop fs -copyFromLocal " + output_tsv_abs_path_in_fs + " " + timestamp_folder_abs_path_for_output_in_hdfs)  # TODO:



                                os.system('hive -S -e "use ' + common.settings['test_or_prod']['hive_db'] + '; msck repair table ' + common.settings['test_or_prod']['hive_table'] + '"')
                                logging.info('hive -S -e "use ' + common.settings['test_or_prod']['hive_db'] + '; msck repair table ' + common.settings['test_or_prod']['hive_table'] + '"')






                                # TODO: [cliu@jobserver2 ~]$ hadoop fs -moveFromLocal algo_dimensionPlusOne/  /user/cliu/arte/fwk/algo/
                                # TODO: in the directory structure. such as ... algo_id/time







                                #raise ValueError('input file generated ???')
                                # TODO: scp to where the file is ...

                                # TODO: move the output to hdfs


                                #logging.info("create template folder inside " + target_dir_abs_path_in_fs + " prod or test folder ")

                                template_algo_dir_abs_path = common.settings['template_src_folder_path_in_fs'] + common.settings['test_or_prod']['target_folder_rel_path'] + algo_dir_rel_path

                                utility.create_folder_if_not_exists(
                                    target_dir_abs_path_in_fs +
                                    current_timestamp_up_to_hundredth_of_a_second)

                                utility.create_folder_if_not_exists(
                                    target_dir_abs_path_in_fs +
                                    current_timestamp_up_to_hundredth_of_a_second +
                                    '/' +
                                    'algo_id=' +
                                    algo_id_in_pending_join_request)

                                # utility.create_folder_if_not_exists(
                                #     target_dir_abs_path_in_fs +
                                #     current_timestamp_up_to_hundredth_of_a_second +
                                #     '/' +
                                #     'algo_id=' +
                                #     algo_id_in_pending_join_request +
                                #     '/' +
                                #     algo_dir_rel_path)

                                os.system("cp -p -r " +
                                          template_algo_dir_abs_path +
                                          " " +
                                          target_dir_abs_path_in_fs +
                                          current_timestamp_up_to_hundredth_of_a_second +
                                          "/" +
                                          "algo_id=" +
                                          algo_id_in_pending_join_request +
                                          "/")

                                logging.info("cp -p -r " +
                                             template_algo_dir_abs_path +
                                             " " +
                                             target_dir_abs_path_in_fs +
                                             current_timestamp_up_to_hundredth_of_a_second +
                                             "/" +
                                             "algo_id=" +
                                             algo_id_in_pending_join_request +
                                             "/")


                                target_algorithm_directory_parent_abs_path_in_fs = \
                                    target_dir_abs_path_in_fs + \
                                    current_timestamp_up_to_hundredth_of_a_second + \
                                    "/" + \
                                    "algo_id=" + \
                                    algo_id_in_pending_join_request + \
                                    "/"

                                target_algorithm_directory_abs_path_in_fs = \
                                    target_algorithm_directory_parent_abs_path_in_fs + \
                                    algo_dir_rel_path

                                output_tsv_des_file_path_in_fs = target_algorithm_directory_abs_path_in_fs + common.settings['data_folder'] + common.settings['output_file']

                                os.system("cp -p " + output_tsv_abs_path_in_fs + " " + output_tsv_des_file_path_in_fs)
                                logging.info("cp -p " + output_tsv_abs_path_in_fs + " " + output_tsv_des_file_path_in_fs)



                                the_resulting_timestamp_directory_in_fs = \
                                    common.settings['global_arte_folder_abs_path_in_tmp_in_fs'] + \
                                    common.settings['test_or_prod']['target_folder_rel_path'] + \
                                    current_timestamp_up_to_hundredth_of_a_second + \
                                    "/"




                                utility.create_folder_if_not_exists(the_resulting_timestamp_directory_in_fs)


                                the_resulting_algorithm_directory_in_fs = \
                                    the_resulting_timestamp_directory_in_fs + \
                                    "algo_id=" + \
                                    algo_id_in_pending_join_request + \
                                    "/" + \
                                    algo_dir_rel_path

                                utility.create_folder_if_not_exists(the_resulting_algorithm_directory_in_fs)


                                logging.info("cp -p -r " +
                                             target_algorithm_directory_abs_path_in_fs +
                                             "* " +
                                             the_resulting_algorithm_directory_in_fs)



                                os.system("cp -p -r " +
                                          target_algorithm_directory_abs_path_in_fs +
                                          "* " +
                                          the_resulting_algorithm_directory_in_fs)





                                #tgz_file_name = str(current_timestamp_up_to_hundredth_of_a_second) + "_" + algo_dir_rel_path[:-1] + ".tgz"
                                tgz_file_name = algo_dir_rel_path[:-1] + ".tgz"
                                # logging.info(tgz_file_name)
                                # os.chdir(target_algorithm_directory_abs_path_in_fs)
                                # logging.info("tar -cvzf " + tgz_file_name + " " + "*") # compress file ...
                                # os.system("tar -cvzf " + tgz_file_name + " " + "*") # compress file ...
                                compressed_file_abs_path = file.compress(os.getcwd(),
                                                                         target_algorithm_directory_parent_abs_path_in_fs,
                                                                         algo_dir_rel_path,
                                                                         tgz_file_name)# TODO: log this output ...
                                logging.info('COMPRESSED FILE PATH: ' + compressed_file_abs_path)


                                # logging.info(target_algorithm_directory_abs_path_in_fs + tgz_file_name)
                                # logging.info("curl --upload-file " + target_algorithm_directory_abs_path_in_fs + tgz_file_name + " " + common.upload['server'] + common.upload['path'])
                                # os.system("curl --upload-file " + target_algorithm_directory_abs_path_in_fs + tgz_file_name + " " + common.upload['server'] + common.upload['path'])


                                http.upload(http_server_target_dir_path +
                                            current_timestamp_up_to_hundredth_of_a_second + '/',
                                            compressed_file_abs_path)



                                # def upload(http_dir_abs_path, local_file_abs_path):
                                #     os.system('curl --upload-file ' + local_file_abs_path + ' ' + http_dir_abs_path)

                                # TODO: DO NOT REMOVE THE FOLLOWING. (THEY ARE USING SSH)
                                #
                                if 'prod' in common.settings['test_or_prod']['target_folder_rel_path']:
                                    logging.info(" disable scp for prod machine now ...")
                                    # deploy_the_resulting_algorithm_directory_in_the_prod_machine(
                                    #     the_resulting_algorithm_directory_in_fs)


                                elif 'test' in common.settings['test_or_prod']['target_folder_rel_path']:
                                    logging.info(" disable scp for test machine now ...")
                                    # deploy_the_resulting_algorithm_directory_in_the_test_machine(
                                    #     the_resulting_algorithm_directory_in_fs)
                                else:
                                    raise ValueError('either only test machine or only production machine can be selected !!!')










                                update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                           PROCESSING_STATUS, COMPLETE_STATUS)
                            else:
                                update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                           PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                                           "empty input file for " + algo_id_in_pending_join_request)
                        else:
                            update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                       PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                                       "missing the input file for " + algo_id_in_pending_join_request)
                    else:  # Good. A nice message :)
                        update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                   PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                                   "missing the mapping func for " + algo_dir_rel_path)
                    timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log += ',' + algo_dir_rel_path[:-1] + \
                                                                                             ".tgz"

        except:
            logging.error('')
            logging.error('unexpected error: ' + str(sys.exc_info()[0]))
            logging.error(traceback.format_exc())

            update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                       PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                       "probably due to hive connection to " + table.read_only_hive['host']+":"+table.read_only_hive['port'])

            #traceback.print_exc(file=sys.stdout)  # TODO: logging ...
            # db.rollback()
            # cursor.close()


        if number_of_valid_algo_ids > 0:

            target_to_add_file_name = common.http['to_add_log_file_name']
                                      #common.settings['test_or_prod']['target_folder_rel_path'][:-1] + '_' + \
                                      #common.upload['to_add_log_file_rel_path']#common.settings['test_or_prod']['http_log_file_name']
            http_server_to_add_log_path = http_server_target_dir_path + \
                                          target_to_add_file_name
                                          #common.upload['to_add_log_file_rel_path']
            logging.info(' Going to log "' + timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log + '" to ' +
                         http_server_to_add_log_path)
            local_to_add_log_path = http.download(http_server_to_add_log_path, target_to_add_file_name)
            if file.contain(local_to_add_log_path, '404'):
                file.empty(local_to_add_log_path)
            file.append2(local_to_add_log_path, timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log)
            http.upload(http_server_target_dir_path, local_to_add_log_path)



        logging.info('')
        logging.info(' The elapsed time: ' + str(time.time() - start_time) + ' seconds.')

        if is_infinite_loop:
            run_yet = False
            time.sleep(period.dequeue)