curl -H "Content-Type: application/json" http://dt02.etl.dw.sc.gwallet.com:8080/DWServices/arte/app/enqueue -d '{"algoId":1}'
curl -H "Content-Type: application/json" http://dt02.etl.dw.sc.gwallet.com:8080/DWServices/arte/app/enqueue -d '{"algoId":901}'
curl -H "Content-Type: application/json" http://dt02.etl.dw.sc.gwallet.com:8080/DWServices/arte/app/enqueue -d '{"algoId":1001}'
