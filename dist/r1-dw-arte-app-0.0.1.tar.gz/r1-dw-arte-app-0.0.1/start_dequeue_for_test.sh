#!/bin/sh

if ps ax | grep -v grep | grep "dequeue.py -test" > /dev/null
then
    echo "previous dequeue run for test not done yet. exit ..."
else
    export PYTHONPATH="/home/arteu/data_prepare/r1-dw-arte-app"
    /opt/python2.7/bin/python /home/arteu/data_prepare/r1-dw-arte-app/application/src/main/python/com/radiumone/arte/fwk/data/prepare/job/dequeue.py -test
fi

#export PYTHONPATH="/home/arteu/data_prepare/r1-dw-arte-app"
#/opt/python2.7/bin/python /home/arteu/data_prepare/r1-dw-arte-app/application/src/main/python/com/radiumone/arte/fwk/data/prepare/job/dequeue.py -test