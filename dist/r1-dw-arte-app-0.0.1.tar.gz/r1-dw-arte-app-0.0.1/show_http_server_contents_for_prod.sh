curl http://jobserver2.dw.sc.gwallet.com/arte/prod/
