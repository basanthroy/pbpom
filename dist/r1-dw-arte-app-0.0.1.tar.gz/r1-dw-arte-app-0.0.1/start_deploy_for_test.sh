#!/bin/sh

if ps ax | grep -v grep | grep "deploy.py -test" > /dev/null
then
    echo "previous deploy run for test not done yet. exit ..."
else
    export PYTHONPATH="/home/cliu/arte_home/data_prepare/r1-dw-arte-app"
    /opt/python2.7/bin/python /home/cliu/arte_home/data_prepare/r1-dw-arte-app/application/src/main/python/com/radiumone/arte/fwk/data/prepare/job/deploy.py -test
fi

#export PYTHONPATH="/home/cliu/arte_home/data_prepare/r1-dw-arte-app"
#/opt/python2.7/bin/python /home/cliu/arte_home/data_prepare/r1-dw-arte-app/application/src/main/python/com/radiumone/arte/fwk/data/prepare/job/deploy.py -test