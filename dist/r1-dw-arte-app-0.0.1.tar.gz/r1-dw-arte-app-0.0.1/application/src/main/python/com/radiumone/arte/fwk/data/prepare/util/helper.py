__author__ = 'cliu'


def get_argument(argv, flag):
    args = str(argv).split()
    flag_idx = -1
    arg_idx = -1
    for arg in args:
        arg_idx += 1
        if arg == flag:
            flag_idx = arg_idx + 1
            break
    return args[flag_idx]


def does_represent_int(s):
    try:
        int(s)
        return True
    except ValueError:
        return False


def if_a_then_set_to_b(ret, a, b):
    if ret == a:
        ret = b
    return ret


def if_none_then_set_to_null(ret):
    return if_a_then_set_to_b(ret, 'None', 'NULL')


def convert_list_of_list_to_string(list_of_list):
    return '\n'.join('\t'.join(map(str, l)) for l in list_of_list)