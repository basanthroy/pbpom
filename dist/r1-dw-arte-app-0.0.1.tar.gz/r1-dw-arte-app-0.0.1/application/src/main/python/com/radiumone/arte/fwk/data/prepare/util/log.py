__author__ = 'cliu'

import logging
import sys


def set_log(filename, level):
    if level == 'DEBUG':
        level = logging.DEBUG
    elif level == 'INFO':
        level = logging.INFO
    elif level == 'WARN':
        level = logging.WARN
    elif level == 'ERROR':
        level = logging.ERROR
    elif level == 'FATAL':
        level = logging.FATAL
    else:
        sys.exit(-1)
    logging.basicConfig(filename=filename, level=level)