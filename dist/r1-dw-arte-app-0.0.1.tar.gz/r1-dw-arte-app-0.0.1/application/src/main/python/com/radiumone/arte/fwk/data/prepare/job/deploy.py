__author__ = 'cliu'

import logging
import sys
import time
import traceback

from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import http as http_config
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import log
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_arte
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_common
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import epoch
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import file
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import http


def main(argv):
    try:

        #######################################
        # check if this is going to run forever
        #
        is_infinite_loop = False
        # for arg in argv:
        #     if arg == '-loop':
        #         is_infinite_loop = True
        #         break

        #############################################
        # check if this is for the production machine
        #
        is_prod_machine = False
        for arg in argv:
            if arg == '-prod':
                is_prod_machine = True
                break
        if is_prod_machine:
            tp_common.settings['test_or_prod'] = tp_common.prod
            tp_arte.target['test_or_prod'] = tp_arte.prod

        ###################
        # configure the log
        #
        target_prefix = tp_common.settings['test_or_prod']['target_folder_rel_path'].strip()[:-1] + '_'
        logging.basicConfig(filename=log.deploy['dir_abs_path'] +
                                     target_prefix +
                                     log.deploy['file'],
                               level=log.deploy['level'])

        ##############################################################
        # was using infinite loop, but, now, use crontab (more stable)
        #
        run_yet = False
        while not run_yet:
            run_yet = True

            start_time = time.time()

            logging.info('')
            logging.info(' ===========================================')
            logging.info(' The deploy job starts at ' + epoch.get_current_time_up_to_second(start_time))
            logging.info(' ===========================================')
            logging.info('')

            if is_prod_machine:
                logging.info(' Going to deploy for prod machine ... ')
            else:
                logging.info(' Going to deploy for test machine ... ')

            ###########################################################
            # get the to add log and last download time file names here
            #
            target_to_add_log_file_name = target_prefix + http_config.to_add_log_file_name# common.http['to_add_log_file_name']
            target_to_add_last_download_time_file_name = target_prefix + http_config.to_add_last_download_time_file_name# common.http['to_add_last_download_time']
            logging.info(" The toAdd log is stored in " + target_to_add_log_file_name + ".")
            logging.info(" The last download time is stored in " + target_to_add_last_download_time_file_name + ".")

            ###########################################################
            # download to add log file from http server to the local fs
            #
            # common.http['server'] + \
            # common.http['arte_dir_abs_path'] + \
            http_server_target_dir_path = http_config.server + \
                                          http_config.arte_dir_abs_path + \
                                          tp_common.settings['test_or_prod']['target_folder_rel_path']
            http_server_to_add_log_path = http_server_target_dir_path + \
                                          target_to_add_log_file_name

            logging.info(" Downloading from " + http_server_to_add_log_path + " to " + target_to_add_log_file_name)
            local_to_add_log_path = http.download(http_server_to_add_log_path, target_to_add_log_file_name)

            ###########################################################################
            # try to get the last download from the local first, instead of http server
            #
            last_download_time = file.get_file_one_line(target_to_add_last_download_time_file_name).strip()
            if len(last_download_time) != 16:
                logging.warn(" The last download time cached locally is " + last_download_time + ".")
                logging.warn(" The last download time is expected in the format of "
                              "YYYY"
                              "MMDD"
                              "hhmm"
                              "ssxx. Hence, reset it to "
                              "0000"
                              "0000"
                              "0000"
                              "0000)")
                last_download_time = '0000' \
                                     '0000' \
                                     '0000' \
                                     '0000'
            logging.info('')
            logging.info(" The last download time cached locally is " + last_download_time + ".")
            logging.info('')

            ##################################################################################################
            # compare the locally cached last download time with the timestamps in the to add log to determine
            # what needs to be downloaded later ...
            #
            current_download_time = last_download_time
            algo_dir_in_tgz_to_tgz_file_path_for_download = {}
            to_add_log_file_handler = open(local_to_add_log_path)
            try:
                for record in to_add_log_file_handler:
                    log_line = record[:-1]  # remove the new line ...
                    log_fields = log_line.split(',')
                    timestamp = log_fields[0]
                    if last_download_time > timestamp:
                        logging.debug(' Since ' + last_download_time + ' > ' + timestamp + ', ignore  ' + log_line)
                    if last_download_time == timestamp:
                        logging.debug(' Since ' + last_download_time + ' = ' + timestamp + ', ignore  ' + log_line)
                    if last_download_time < timestamp:
                        logging.info(' Since ' + last_download_time + ' < ' + timestamp + ', process ' + log_line)
                        for index, algo_dir_tgz in enumerate(log_fields):
                            if index > 0:  # after first one, it's not timestamp ...
                                http_download_tgz_file_path = http_server_target_dir_path + timestamp + '/' + algo_dir_tgz
                                logging.info(' Going to download/decompress/deploy ' + http_download_tgz_file_path +
                                             ' later.')
                                algo_dir_in_tgz_to_tgz_file_path_for_download[algo_dir_tgz] = http_download_tgz_file_path
                    logging.info('')
            except:
                logging.error('')
                logging.error('unexpected error: ' + str(sys.exc_info()[0]))
                logging.error(traceback.format_exc())
            finally:
                current_download_time = timestamp
                logging.info(' Closing the file handler for ' + local_to_add_log_path + ' ... ')
                to_add_log_file_handler.close()

            ##################################################
            # find out where to deploy the algorithm directory
            #
            to_add_dir_abs_path = tp_arte.target['test_or_prod']['deploy_arte_home_abs_path'] + tp_arte.to_add_directory_rel_path
            logging.info(' To deploy, the algorithm directories need to be moved to ' + to_add_dir_abs_path)
            logging.info('')

            #########################################
            # Going to download/decompress/deploy now
            #
            for algo_dir_in_tgz, http_algo_dir_tgz_file_path in algo_dir_in_tgz_to_tgz_file_path_for_download.iteritems():
                logging.info(' *******************************************************************************************')

                logging.info(' ' + algo_dir_in_tgz + ' -> ' + http_algo_dir_tgz_file_path)
                logging.info(' ')
                logging.info(' (1/3) Downloading ' + http_algo_dir_tgz_file_path)
                local_algo_dir_tgz_file_path = http.download(http_algo_dir_tgz_file_path, algo_dir_in_tgz)

                logging.info(' ')
                logging.info(' (2/3) Decompressing ' + local_algo_dir_tgz_file_path)
                decompressed_algo_dir_path = file.decompress(local_algo_dir_tgz_file_path)

                algo_dir_name = decompressed_algo_dir_path.split('/')[-1]
                logging.info('')
                logging.info(' (3/3) Deploying ' + algo_dir_name)
                file.remove(to_add_dir_abs_path + algo_dir_name)
                file.move(decompressed_algo_dir_path, to_add_dir_abs_path)

                logging.info('')
                logging.info(decompressed_algo_dir_path + ' is deployed by moving it to ' + to_add_dir_abs_path)

                logging.info(' ===========================================================================================')

            file.touch(to_add_dir_abs_path)  # Note: even if nothing to add, still update the to add directory timestamp :)

            last_download_time = current_download_time

            #
            # once the local cached last download time is set, the previously downloaded won't be downloaded again.
            # note: by setting the last down time to be 0s, everything in log will be reconsidered !!!
            #
            file.set_file_one_line(target_to_add_last_download_time_file_name, last_download_time)

            logging.info('')
            logging.info(" Now, the last download time is " + last_download_time + ".")

            end_time = time.time()
            logging.info('')
            logging.info(' ===========================================')
            logging.info(' The deploy job ends at ' + epoch.get_current_time_up_to_second(end_time))
            logging.info(' The deploy job elapsed time is ' + str(end_time - start_time) + ' seconds.')
            logging.info(' ===========================================')
            logging.info('')

            if is_infinite_loop:
                run_yet = False
                time.sleep(1000)

    except:
        logging.error('')
        logging.error(' Unexpected error: ' + str(sys.exc_info()[0]))
        logging.error(traceback.format_exc())
        sys.exit(-1)

if __name__ == '__main__':
    sys.exit(main(sys.argv))