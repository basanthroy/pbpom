__author__ = 'cliu'

test = {'target_folder_rel_path': 'test/'}

prod = {'target_folder_rel_path': 'prod/'}

settings = {'bin_python': '/opt/python2.7/bin/python',
            'test_or_prod': test  # by default, it's test
}