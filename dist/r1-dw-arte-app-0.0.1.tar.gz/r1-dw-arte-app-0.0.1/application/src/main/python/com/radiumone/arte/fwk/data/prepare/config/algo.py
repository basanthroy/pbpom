__author__ = 'cliu'

r1_dw_arte_algo_dir_abs_path = '/opt/dwradiumone/arte/app/data_prepare/r1-dw-arte-algo/'  # for prod ... but for test ok too
#r1_dw_arte_algo_dir_abs_path = '/home/arteu/data_prepare/r1-dw-arte-algo/'  # NOTE: this repos can be used for test ...

template_src_folder_abs_path_in_fs = r1_dw_arte_algo_dir_abs_path + 'template/'

algo_sitePlusOne = {'algo_dir_rel_path': 'algo_sitePlusOne/', 'mapping_func': 'arte_bid_price_mapping.py'}

algo_uuidPlusOne = {'algo_dir_rel_path': 'algo_uuidPlusOne/', 'mapping_func': 'arte_bid_price_mapping.py'}

algo_siteGeozipPlusTwo = {'algo_dir_rel_path': 'algo_siteGeozipPlusTwo/', 'mapping_func': 'arte_bid_price_mapping.py'}

get = {'1': algo_sitePlusOne, '2': algo_uuidPlusOne, '901': algo_siteGeozipPlusTwo}













