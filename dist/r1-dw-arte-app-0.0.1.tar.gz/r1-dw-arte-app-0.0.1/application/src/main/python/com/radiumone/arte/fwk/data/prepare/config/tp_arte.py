__author__ = 'cliu'

test = {'deploy_arte_home_abs_path': '/home/cliu/arte_home/'}

prod = {'deploy_arte_home_abs_path': '/opt/apps/arte_home/'}

target = {'test_or_prod': test}

to_add_directory_rel_path = 'fwk/algo/toAdd/'