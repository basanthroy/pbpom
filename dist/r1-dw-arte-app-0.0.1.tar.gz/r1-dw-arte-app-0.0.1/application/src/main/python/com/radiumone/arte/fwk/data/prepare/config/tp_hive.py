__author__ = 'cliu'

delimit = '\001'

credentials_dir_path = '/opt/dwradiumone/arte/app/data_prepare/credentials/'

host          = 'jobserver.dw.sc.gwallet.com'
port          = '10000'
user          = credentials_dir_path + 'jobserver_hive/user'
passwd        = credentials_dir_path + 'jobserver_hive/passwd'
authMechanism = 'PLAIN'

test = {'hive_db': 'chuchi_tmp',
        'hive_table': 'output_log'}

prod = {'hive_db': 'adpred',
        'hive_table': 'output_log'}

target = {'test_or_prod': test}