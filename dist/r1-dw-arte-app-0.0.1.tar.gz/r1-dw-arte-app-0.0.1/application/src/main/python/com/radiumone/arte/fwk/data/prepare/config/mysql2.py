__author__ = 'cliu'

read_write_tmp_strategy_to_algo_table = {'name': 'TMP_STRATEGY_TO_ALGO',
                                         'columns': 'strategy_id, '
                                                    'algo_id',
                                         'create_statement': 'CREATE TABLE TMP_STRATEGY_TO_ALGO ('
                                                             'strategy_id int(11), '
                                                             'algo_id int(11), '
                                                             'PRIMARY KEY (strategy_id, algo_id)'
                                                             ')'}

read_write_tmp_strategy_view = {'name': 'TMP_STRATEGIES_VIEW',
                                'create_statement': 'CREATE VIEW TMP_STRATEGIES_VIEW AS '
                                                    'SELECT s.strategy_id, s.max_bid, s.min_bid, sa.algo_id '
                                                    'FROM '
                                                    'TMP_STRATEGIES s, '
                                                    'TMP_STRATEGY_TO_ALGO sa '
                                                    'WHERE s.strategy_id = sa.strategy_id;'}