__author__ = 'cliu'

import os

ERROR_CODE_NOT_FOUND = '404'


def download(http_file_abs_path, tgt_file_name):
    os.system('curl -o ' + tgt_file_name + ' ' + http_file_abs_path)
    return os.getcwd()+'/'+ tgt_file_name  # http_file_abs_path.rsplit('/', 1)[-1]


def upload(http_dir_abs_path, local_file_abs_path):
    os.system('curl --upload-file ' + local_file_abs_path + ' ' + http_dir_abs_path)


