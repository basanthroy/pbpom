__author__ = 'cliu'

import os


def make_directory(dir_abs_path):
    os.system("hadoop fs -mkdir -p " + dir_abs_path)


def copy_to_local(remote_abs_path, local_abs_path):
    os.system("hadoop fs -copyToLocal " + remote_abs_path + " " + local_abs_path)


def copy_from_local(local_abs_path, remote_abs_path):
    os.system("hadoop fs -copyFromLocal " + local_abs_path + " " + remote_abs_path)