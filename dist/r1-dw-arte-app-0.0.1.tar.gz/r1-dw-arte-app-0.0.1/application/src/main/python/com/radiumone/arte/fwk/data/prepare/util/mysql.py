__author__ = 'cliu'

import MySQLdb


def run_sql_without_db_with_commit(mysql_host_name,  # tested indirectly
                                   mysql_user_name,
                                   mysql_password,
                                   mysql_statement):
    ret = []
    # db = mysql.connector.connect(host=mysql_host_name,
    #                               user=mysql_user_name,
    #                               password=mysql_password)
    db = MySQLdb.connect(mysql_host_name,
                         mysql_user_name,
                         mysql_password)
    cursor = db.cursor()
    try:
        cursor.execute(mysql_statement)

        for row in cursor:
            row_str_list = []
            for col in row:
                row_str_list.append(str(col))  # otherwise, encoding error ...
            ret.append(row_str_list)

        db.commit()
    except:
        db.rollback()
        cursor.close()
        raise  # not going to handle any exceptions here ...

    cursor.close()
    return ret


def run_sql_with_db_with_commit(mysql_host_name,  # tested indirectly
                                mysql_user_name,
                                mysql_password,
                                mysql_database,
                                mysql_statement):
    ret = []
    # db = mysql.connector.connect(host=mysql_host_name,
    #                               user=mysql_user_name,
    #                               password=mysql_password,
    #                               database=mysql_database)
    db = MySQLdb.connect(mysql_host_name,
                         mysql_user_name,
                         mysql_password,
                         mysql_database)
    cursor = db.cursor()
    try:
        cursor.execute(mysql_statement)

        for row in cursor:
            row_str_list = []
            for col in row:
                row_str_list.append(str(col))  # otherwise, encoding error ...
            ret.append(row_str_list)

        db.commit()
    except:
        db.rollback()
        cursor.close()
        raise  # not going to handle any exceptions here ...

    cursor.close()
    return ret


def run_sql_without_db(mysql_host_name,  # tested indirectly
                       mysql_user_name,
                       mysql_password,
                       sql):
    ret = []
    # db = mysql.connector.connect(host=mysql_host_name,
    #                               user=mysql_user_name,
    #                               password=mysql_password)
    db = MySQLdb.connect(mysql_host_name,
                         mysql_user_name,
                         mysql_password)
    cursor = db.cursor()
    cursor.execute(sql)
    for row in cursor:
        row_str_list = []
        for col in row:
            row_str_list.append(str(col))  # otherwise, encoding error ...
        ret.append(row_str_list)
    cursor.close()
    return ret


def run_sql_with_db(mysql_host_name,  # tested indirectly
                    mysql_user_name,
                    mysql_password,
                    mysql_database,
                    sql):
    ret = []
    # db = mysql.connector.connect(host=mysql_host_name,
    #                               user= mysql_user_name,
    #                               password=mysql_password,
    #                               database=mysql_database)
    db = MySQLdb.connect(mysql_host_name,
                         mysql_user_name,
                         mysql_password,
                         mysql_database)
    cursor = db.cursor()

    cursor.execute(sql)
    for row in cursor:
        row_str_list = []
        for col in row:
            row_str_list.append(str(col))  # otherwise, encoding error ...
        ret.append(row_str_list)
    cursor.close()
    return ret


def does_database_exist(mysql_host_name,  # tested
                        mysql_user_name,
                        mysql_password,
                        mysql_database):
    ret = False
    try:
        mysql_result = run_sql_without_db(mysql_host_name,
                                          mysql_user_name,
                                          mysql_password,
                                          "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = "
                                          "'" +
                                          mysql_database +
                                          "'")
        if len(mysql_result) > 0:
            ret = True
    except:
        raise
    return ret


def does_table_exist(mysql_host_name,  # tested
                     mysql_user_name,
                     mysql_password,
                     mysql_database,
                     mysql_table):
    ret = True
    try:
        run_sql_with_db(mysql_host_name,
                        mysql_user_name,
                        mysql_password,
                        mysql_database,
                        'SELECT 1 FROM ' + mysql_table + ' LIMIT 1')
    except:
        ret = False
    return ret


def does_view_exist(mysql_host_name,  # tested
                    mysql_user_name,
                    mysql_password,
                    mysql_database,
                    mysql_view):
    ret = False
    try:
        mysql_result = run_sql_without_db(mysql_host_name,
                                          mysql_user_name,
                                          mysql_password,
                                          "SELECT * FROM INFORMATION_SCHEMA.VIEWS WHERE table_name = "
                                          "'" +
                                          mysql_view +
                                          "'"
                                          " AND TABLE_SCHEMA = "
                                          "'" +
                                          mysql_database +
                                          "'")
        if len(mysql_result) > 0:
            ret = True
    except:
        raise
    return ret


def create_database_if_not_exists(mysql_host_name,  # tested
                                  mysql_user_name,
                                  mysql_password,
                                  mysql_database):
    if not does_database_exist(mysql_host_name,
                               mysql_user_name,
                               mysql_password,
                               mysql_database):
        run_sql_without_db_with_commit(mysql_host_name,
                                       mysql_user_name,
                                       mysql_password,
                                       'CREATE DATABASE ' + mysql_database)


def create_table_if_not_exists(mysql_host_name,  # tested
                               mysql_user_name,
                               mysql_password,
                               mysql_database,
                               mysql_table,
                               mysql_create_table_statement):
    create_database_if_not_exists(mysql_host_name,
                                  mysql_user_name,
                                  mysql_password,
                                  mysql_database)
    if not does_table_exist(mysql_host_name,
                            mysql_user_name,
                            mysql_password,
                            mysql_database,
                            mysql_table):
        run_sql_with_db_with_commit(mysql_host_name,
                                    mysql_user_name,
                                    mysql_password,
                                    mysql_database,
                                    mysql_create_table_statement)


def create_view_if_not_exists(mysql_host_name,  # tested
                              mysql_user_name,
                              mysql_password,
                              mysql_database,
                              mysql_view,
                              mysql_create_view_statement):
    create_database_if_not_exists(mysql_host_name,
                                  mysql_user_name,
                                  mysql_password,
                                  mysql_database)
    if not does_view_exist(mysql_host_name,
                           mysql_user_name,
                           mysql_password,
                           mysql_database,
                           mysql_view):
        run_sql_with_db_with_commit(mysql_host_name,
                                    mysql_user_name,
                                    mysql_password,
                                    mysql_database,
                                    mysql_create_view_statement)