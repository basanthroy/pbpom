__author__ = 'cliu'

hash_method = 'md5'  # md5 or sha1

test = {'hash_file': 'test_previous.hash'}
prod = {'hash_file': 'prod_previous.hash'}

target = {'test_or_prod': test}