__author__ = 'cliu'

credentials_dir_path = '/opt/dwradiumone/arte/app/data_prepare/credentials/'

read_only_mysql = {'host': 'report1.dw.sc.gwallet.com',
                   'user': credentials_dir_path + 'read_only_mysql/user',
                   'passwd': credentials_dir_path + 'read_only_mysql/passwd',
                   'default_db': 'radiumone_master'}

read_only_strategies_table = {'db': read_only_mysql['default_db'],
                              'name': 'STRATEGIES',
                              'columns': 'strategy_id, '
                                         'max_bid, '
                                         'min_bid, '
                                         'algo_id',
                              #
                              # TODO: we will use the above one once algo_id col is there !!!
                              # Note: TMP_STRATEGIES only has 3 columns.
                              #       That is what we can get so far until algo_id is there !!!
                              #
                              'tmp_name': 'TMP_STRATEGIES',
                              'tmp_columns': 'strategy_id, '
                                             'max_bid, '
                                             'min_bid',
                              'tmp_create_statement': 'CREATE TABLE TMP_STRATEGIES ('
                                                      'strategy_id  int(11) NOT NULL, '
                                                      'max_bid decimal(10,4), '
                                                      'min_bid decimal(10,4), '
                                                      'PRIMARY KEY (strategy_id)'
                                                      ')'}

test = {'db': 'test_arte'}
prod = {'db':      'arte'}

read_write_mysql = {'host': '10.101.4.135',  # que2 mysql: auto increment by 4 (starts at 2)
                    'user': credentials_dir_path + 'read_write_mysql/user',
                    'passwd': credentials_dir_path + 'read_write_mysql/passwd',
                    'test_or_prod': test}  # by default, it's test.

read_write_strategies_table = {'name': 'STRATEGIES',
                               #
                               # Note: TMP_STRATEGIES_VIEW is the view from TMP_STRATEGIES & TMP_STRATEGY_TO_ALGO
                               #
                               'tmp_name': 'TMP_STRATEGIES_VIEW',
                               'previous': 'PREVIOUS_STRATEGIES',
                               'columns': 'strategy_id, '
                                          'max_bid, '
                                          'min_bid, '
                                          'algo_id',
                               'column_definitions': 'strategy_id  int(11) NOT NULL, '
                                                     'max_bid decimal(10,4), '
                                                     'min_bid decimal(10,4), '
                                                     'algo_id      int(11), '
                                                     'PRIMARY KEY (strategy_id)',
                               'create_statement': 'CREATE TABLE STRATEGIES ('
                                                   'strategy_id  int(11) NOT NULL, '
                                                   'max_bid decimal(10,4), '
                                                   'min_bid decimal(10,4), '
                                                   'algo_id      int(11), '
                                                   'PRIMARY KEY (strategy_id)'
                                                   ')'}

read_write_join_requests_table = {'name': 'JOIN_REQUESTS',
                                  'columns': 'create_ts, '
                                             'algo_id, '
                                             'update_ts, '
                                             'status',
                                  'column_definitions': 'request_id BIGINT NOT NULL AUTO_INCREMENT, '
                                                        'create_ts  VARCHAR(20), '  # int(11), '
                                                        'algo_id    INT, '
                                                        'update_ts  VARCHAR(20), '  # int(11), '
                                                        'status     VARCHAR(255), '
                                                        'PRIMARY KEY (request_id)',
                                  'create_statement':   'CREATE TABLE JOIN_REQUESTS ('
                                                        'request_id BIGINT NOT NULL AUTO_INCREMENT, '
                                                        'create_ts  VARCHAR(20), '  # int(11), '
                                                        'algo_id    INT, '
                                                        'update_ts  VARCHAR(20), '  # int(11), '
                                                        'status     VARCHAR(255), '
                                                        'PRIMARY KEY (request_id)'
                                                        ')'}