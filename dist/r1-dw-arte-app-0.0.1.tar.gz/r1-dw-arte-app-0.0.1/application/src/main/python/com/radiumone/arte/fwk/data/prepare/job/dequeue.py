__author__ = 'cliu'

import logging
import MySQLdb
import pyhs2
import os
import sys
import time
import traceback

from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import algo
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import data
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import http as http_config
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import log
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_common
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_hive
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_mysql
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.job import enqueue
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.job import enqueue2
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import file
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import hdfs
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import hive
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import http
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import mysql
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import epoch
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import helper

PENDING_STATUS = "pending"
PROCESSING_STATUS = "processing"
COMPLETE_STATUS = "complete"
ERROR_STATUS_PREFIX = "error: "


def get_strategies_to_join_in_mysql(db):
    select_strategies_to_join_statement = 'SELECT ' + \
                                          tp_mysql.read_write_strategies_table['columns'] + ' ' + \
                                          'FROM ' + \
                                          tp_mysql.read_write_strategies_table['tmp_name']
    logging.info(" Going to get all the strategy data for doing the join through the following:")
    logging.info(' In db, ' + db + ', executing the sql statement: ' + select_strategies_to_join_statement)
    return mysql.run_sql_with_db(tp_mysql.read_write_mysql['host'],
                                 file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                 file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                 db,
                                 select_strategies_to_join_statement)


def get_select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement(
        algo_id_in_pending_join_request_str):
    logging.info(" Return the query for retrieving all the data from adpred.arte_dimension_predictions for"
                 " the pending algo_id: " + algo_id_in_pending_join_request_str)
    return 'SELECT * FROM adpred.arte_dimension_predictions WHERE algo_id = ' + algo_id_in_pending_join_request_str


def update_join_request_status_given_cursor(db, cursor_obj, epoch_time, algo_id_string, src_status_str, dst_status_str):
    current_time_up_to_hundredth_of_a_second = epoch.get_current_time_up_to_hundredth_of_a_second(epoch_time)
    update_status_statement = 'UPDATE ' + \
                              tp_mysql.read_write_join_requests_table['name'] + ' ' + \
                              'SET ' + \
                              'update_ts = ' + current_time_up_to_hundredth_of_a_second + ', ' + \
                              'status = "' + dst_status_str + '" ' + \
                              'WHERE ' + \
                              'algo_id = ' + algo_id_string + ' ' + \
                              'AND ' + \
                              'status = "' + src_status_str + '"'
    logging.info(' Going to set the status from "' + src_status_str + '" to "' + dst_status_str +
                 '" for algo_id: ' + algo_id_string + ' at ' + current_time_up_to_hundredth_of_a_second +
                 ' through the following:')
    logging.info(' In db, ' + db + ', executing the sql statement: ' + update_status_statement)
    cursor_obj.execute(update_status_statement)


def update_join_request_status(db, epoch_time, algo_id_string, src_status_str, dst_status_str):
    current_time_up_to_hundredth_of_a_second = epoch.get_current_time_up_to_hundredth_of_a_second(epoch_time)
    update_status_statement = 'UPDATE ' + \
                              tp_mysql.read_write_join_requests_table['name'] + ' ' + \
                              'SET ' + \
                              'update_ts = ' + current_time_up_to_hundredth_of_a_second + ', ' + \
                              'status = "' + dst_status_str + '" ' + \
                              'WHERE ' + \
                              'algo_id = ' + algo_id_string + ' ' + \
                              'AND ' + \
                              'status = "' + src_status_str + '"'
    logging.info(' Going to set the status from "' + src_status_str + '" to "' + dst_status_str +
                 '" for algo_id: ' + algo_id_string + ' at ' + current_time_up_to_hundredth_of_a_second +
                 ' through the following:')
    logging.info(' In db, ' + db + ', executing the sql statement: ' + update_status_statement)
    mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                        file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                        file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                        db,
                                        update_status_statement)


def run_mapping_func(mapping_function_abs_path_str,
                     input_fsv_abs_path_str,
                     output_tsv_abs_path_str,
                     output_log_abs_path_str):
    logging.info(" Going to run map func, " + mapping_function_abs_path_str + ", with input: " + input_fsv_abs_path_str)
    os.system(tp_common.settings['bin_python'] + ' ' +
              mapping_function_abs_path_str + ' ' +
              input_fsv_abs_path_str + ' ' +
              output_tsv_abs_path_str + ' ' +
              output_log_abs_path_str)
    logging.info(" Done running ...")
    logging.info(" The generated output from the mapping function: " + output_tsv_abs_path_str)
    logging.info(" The generated log    from the mapping function: " + output_log_abs_path_str)


def pre_setup_for_hdfs(algo_id_in_pending_join_request,
                       target_dir_abs_path_in_hdfs,
                       algo_id_equal_to_algo_id_in_pending_join_request_rel_path,
                       dt_equal_to_dt_rel_path,
                       current_timestamp_up_to_hundredth_of_a_second_prefix):

    ####################################################################################################################
    # prepare the list of folder(s)/file(s) in the hadoop distributed file system ######################################
    ####################################################################################################################

    # hdfs's func folder
    #
    logging.info('')
    function_folder_abs_path_in_hdfs = \
        target_dir_abs_path_in_hdfs + \
        data.func_folder_rel_path + \
        algo_id_equal_to_algo_id_in_pending_join_request_rel_path
    logging.info(' In HDFS, ' + function_folder_abs_path_in_hdfs)

    # hdfs's func file
    #
    mapping_function_abs_path_in_hdfs = function_folder_abs_path_in_hdfs + \
                                        algo.get[algo_id_in_pending_join_request]['mapping_func']
    logging.info(' In HDFS, ' + mapping_function_abs_path_in_hdfs)

    # hdfs's log folder
    #
    timestamp_folder_abs_path_for_log_in_hdfs = \
        target_dir_abs_path_in_hdfs + \
        data.log_folder_rel_path + \
        algo_id_equal_to_algo_id_in_pending_join_request_rel_path + \
        dt_equal_to_dt_rel_path
    logging.info(' In HDFS, ' + timestamp_folder_abs_path_for_log_in_hdfs)

    # hdfs's log file
    #
    output_log_abs_path_in_hdfs = timestamp_folder_abs_path_for_log_in_hdfs + \
                                  current_timestamp_up_to_hundredth_of_a_second_prefix + \
                                  data.log_file
    logging.info(' In HDFS, ' + output_log_abs_path_in_hdfs)

    # hdfs's input folder
    #
    timestamp_folder_abs_path_for_input_in_hdfs = \
        target_dir_abs_path_in_hdfs + \
        data.input_folder_rel_path + \
        algo_id_equal_to_algo_id_in_pending_join_request_rel_path + \
        dt_equal_to_dt_rel_path
    logging.info(' In HDFS, ' + timestamp_folder_abs_path_for_input_in_hdfs)

    # hdfs's input file
    #
    input_fsv_abs_path_in_hdfs = timestamp_folder_abs_path_for_input_in_hdfs + \
                                 current_timestamp_up_to_hundredth_of_a_second_prefix + \
                                 data.input_file
    logging.info(' In HDFS, ' + input_fsv_abs_path_in_hdfs)

    # hdfs's output folder
    #
    timestamp_folder_abs_path_for_output_in_hdfs = \
        target_dir_abs_path_in_hdfs + \
        data.output_folder_rel_path + \
        algo_id_equal_to_algo_id_in_pending_join_request_rel_path + \
        dt_equal_to_dt_rel_path
    logging.info(' In HDFS, ' + timestamp_folder_abs_path_for_output_in_hdfs)

    # hdfs's output file
    #
    output_tsv_abs_path_in_hdfs = timestamp_folder_abs_path_for_output_in_hdfs + \
                                  current_timestamp_up_to_hundredth_of_a_second_prefix + \
                                  data.output_file
    logging.info(' In HDFS, ' + output_tsv_abs_path_in_hdfs)

    # create the 3 hdfs's folders mentioned above ...
    #
    hdfs.make_directory(timestamp_folder_abs_path_for_log_in_hdfs)
    hdfs.make_directory(timestamp_folder_abs_path_for_input_in_hdfs)
    hdfs.make_directory(timestamp_folder_abs_path_for_output_in_hdfs)

    return mapping_function_abs_path_in_hdfs, \
           timestamp_folder_abs_path_for_input_in_hdfs, \
           timestamp_folder_abs_path_for_output_in_hdfs, \
           timestamp_folder_abs_path_for_log_in_hdfs


def pre_setup_tmp_for_fs(algo_id_in_pending_join_request, target_dir_abs_path_in_tmp_in_fs,
                         algo_id_equal_to_algo_id_in_pending_join_request_rel_path, dt_equal_to_dt_rel_path,
                         current_timestamp_up_to_hundredth_of_a_second_prefix):

    ####################################################################################################################
    # prepare the list of folder(s)/file(s) in the local file system ###################################################
    ####################################################################################################################

    file.remove_recursively(target_dir_abs_path_in_tmp_in_fs)
    logging.info('')

    ####################################################################################################################
    # (1/4) func folder
    #
    function_folder_abs_path_in_tmp_fs = \
        target_dir_abs_path_in_tmp_in_fs + data.func_folder_rel_path + \
        algo_id_equal_to_algo_id_in_pending_join_request_rel_path
    logging.info(' In   FS, ' + function_folder_abs_path_in_tmp_fs)
    file.create_folder_if_not_exists(function_folder_abs_path_in_tmp_fs)
    #
    # mapping func (inside func folder)
    #
    mapping_function_abs_path_in_tmp_in_fs = \
        function_folder_abs_path_in_tmp_fs + \
        current_timestamp_up_to_hundredth_of_a_second_prefix + \
        algo.get[algo_id_in_pending_join_request]['mapping_func']
    logging.info(' In   FS, ' + mapping_function_abs_path_in_tmp_in_fs)

    ####################################################################################################################
    # (2/4) log folder
    #
    timestamp_folder_abs_path_for_log_in_tmp_in_fs = \
        target_dir_abs_path_in_tmp_in_fs + data.log_folder_rel_path + \
        algo_id_equal_to_algo_id_in_pending_join_request_rel_path + \
        dt_equal_to_dt_rel_path
    logging.info(' In   FS, ' + timestamp_folder_abs_path_for_log_in_tmp_in_fs)
    file.create_folder_if_not_exists(timestamp_folder_abs_path_for_log_in_tmp_in_fs)
    #
    # output log file (inside log folder)
    #
    output_log_abs_path_in_tmp_in_fs = \
        timestamp_folder_abs_path_for_log_in_tmp_in_fs + \
        current_timestamp_up_to_hundredth_of_a_second_prefix + \
        data.log_file
    logging.info(' In   FS, ' + output_log_abs_path_in_tmp_in_fs)

    ####################################################################################################################
    # (3/4) input folder
    #
    timestamp_folder_abs_path_for_input_in_tmp_in_fs = \
        target_dir_abs_path_in_tmp_in_fs + data.input_folder_rel_path + \
        algo_id_equal_to_algo_id_in_pending_join_request_rel_path + \
        dt_equal_to_dt_rel_path
    logging.info(' In   FS, ' + timestamp_folder_abs_path_for_input_in_tmp_in_fs)
    file.create_folder_if_not_exists(timestamp_folder_abs_path_for_input_in_tmp_in_fs)
    #
    # input file (inside input folder)
    #
    input_fsv_abs_path_in_tmp_in_fs = \
        timestamp_folder_abs_path_for_input_in_tmp_in_fs + \
        current_timestamp_up_to_hundredth_of_a_second_prefix + \
        data.input_file
    logging.info(' In   FS, ' + input_fsv_abs_path_in_tmp_in_fs)

    ####################################################################################################################
    # (4/4) output folder
    #
    timestamp_folder_abs_path_for_output_in_tmp_in_fs = \
        target_dir_abs_path_in_tmp_in_fs + data.output_folder_rel_path + \
        algo_id_equal_to_algo_id_in_pending_join_request_rel_path + \
        dt_equal_to_dt_rel_path
    logging.info(' In   FS, ' + timestamp_folder_abs_path_for_output_in_tmp_in_fs)
    file.create_folder_if_not_exists(timestamp_folder_abs_path_for_output_in_tmp_in_fs)
    #
    # output file (inside output folder)
    #
    output_tsv_abs_path_in_tmp_in_fs = \
        timestamp_folder_abs_path_for_output_in_tmp_in_fs + \
        current_timestamp_up_to_hundredth_of_a_second_prefix + \
        data.output_file
    logging.info(' In   FS, ' + output_tsv_abs_path_in_tmp_in_fs)

    return mapping_function_abs_path_in_tmp_in_fs, \
           input_fsv_abs_path_in_tmp_in_fs, \
           output_tsv_abs_path_in_tmp_in_fs, \
           output_log_abs_path_in_tmp_in_fs


def get_strategy_id_algo_id_to_arte_min_max_bids_mapping(strategies_to_join):
    strategy_id_algo_id_to_arte_min_max_bids_mapping = {}
    for strategy_to_join in strategies_to_join:
        strategy_id_algo_id_to_arte_min_max_bids_mapping[
            str(strategy_to_join[0]) + tp_hive.delimit + str(strategy_to_join[3])] = \
            str(strategy_to_join[2]) + tp_hive.delimit + str(strategy_to_join[1])
        logging.debug(' ' +
                      str(strategy_to_join[0]) + ',' + str(strategy_to_join[3]) + ' -> ' +
                      str(strategy_to_join[2]) + ',' + str(strategy_to_join[1]))
    return strategy_id_algo_id_to_arte_min_max_bids_mapping


def is_algo_id_valid(rw_db, algo_id_in_pending_join_request, is_prod_machine):
    algo_id_valid = True
    if helper.does_represent_int(algo_id_in_pending_join_request):
        logging.info(" It's a integer.")
        if enqueue.is_valid_algo_id(algo_id_in_pending_join_request):
            logging.info(" It's a valid algorithm id.")
            logging.info(
                " The algorithm id, " + algo_id_in_pending_join_request + ", is going to be dequeue-ed SUCCESSFULLY :)")
            if is_prod_machine and int(algo_id_in_pending_join_request) >= 900 and int(
                    algo_id_in_pending_join_request) <= 999:
                update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                           PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                           '900 level algo id is not allowed in the production machine.')
                # continue
                algo_id_valid = False
        else:
            logging.info(" It's NOT a valid algorithm id.")
            logging.info(
                " The algorithm id, " + algo_id_in_pending_join_request + ", FAILED to be dequeue-ed :(")
            update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                       PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                       algo_id_in_pending_join_request +
                                       " is not a valid algo id.")
            # continue
            algo_id_valid = False

    else:
        logging.info(" It's NOT a integer.")
        logging.info(" The algorithm id, " + algo_id_in_pending_join_request +
                     ", FAILED to be dequeue-ed :(")
        update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                   PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                   algo_id_in_pending_join_request +
                                   " is not an integer.")
        # continue
        algo_id_valid = False
    return algo_id_valid


def get_dimension_predictions_to_join(algo_id_in_pending_join_request):

    dimension_predictions_to_join = []
    dimension_predictions_count = 0

    select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement = \
        get_select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement(
            algo_id_in_pending_join_request)

    logging.info('')
    logging.info(" Getting data from hive ...")

    with pyhs2.connect(host=tp_hive.host,
                       user=file.get_file_one_line(tp_hive.user),
                       password=file.get_file_one_line(tp_hive.passwd),
                       port=tp_hive.port,
                       authMechanism=tp_hive.authMechanism) as conn:
        with conn.cursor() as cur:
            logging.info('')
            logging.info(
                ' In host, ' + tp_hive.host + ', executing the hql statement: ' +
                select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement)
            cur.execute(
                select_dimension_predictions_to_join_for_algo_id_in_pending_join_request_statement)
            for i in cur.fetch():
                dimension_predictions_count += 1
                logging.debug('\t' + str(dimension_predictions_count) + '\t' + str(i))
                dimension_predictions_to_join.append(i)

            logging.info(' Closing the connection to hive ...')
            cur.close()
            logging.info('')

    return dimension_predictions_to_join, dimension_predictions_count


def generate_input_from_join(input_fsv_abs_path_in_tmp_in_fs,
                             algo_id_in_pending_join_request,
                             dimension_predictions_to_join,
                             strategy_id_and_algo_id_to_join______is_mapped_to______arte_min_bid_and_arte_max_bid, dt,
                             current_timestamp_up_to_hundredth_of_a_second):
    file.empty(input_fsv_abs_path_in_tmp_in_fs)
    input_file_writer = open(input_fsv_abs_path_in_tmp_in_fs, 'w')
    is_file_empty = True
    line_counter = 0
    for dimension_prediction_to_join in dimension_predictions_to_join:
        strategy_id = str(dimension_prediction_to_join[0])
        dimension_value_structs = dimension_prediction_to_join[1]
        probability_score = str(dimension_prediction_to_join[2])
        if algo_id_in_pending_join_request != dimension_prediction_to_join[3]:  # 4th col is algo_id
            raise ValueError('algo_id_in_pending_join_request' + algo_id_in_pending_join_request +
                             ' != '
                             'dimension_prediction_to_join[3]' + dimension_prediction_to_join[3])
        strategy_id_and_algo_id_to_join = strategy_id + tp_hive.delimit + algo_id_in_pending_join_request
        #
        # This key might cause an error if
        # 1) an inexistent strategy_id or
        # 2) min_bid is not set ? (the min_bid and max_bid must be set)
        #
        one_line = \
            strategy_id + \
            tp_hive.delimit + algo_id_in_pending_join_request + \
            tp_hive.delimit + dimension_value_structs + \
            tp_hive.delimit + probability_score + \
            tp_hive.delimit + \
            strategy_id_and_algo_id_to_join______is_mapped_to______arte_min_bid_and_arte_max_bid[
                strategy_id_and_algo_id_to_join] + \
            tp_hive.delimit + dt + \
            tp_hive.delimit + current_timestamp_up_to_hundredth_of_a_second + '\n'
        line_counter += 1
        if is_file_empty:
            is_file_empty = False
        input_file_writer.write(one_line)
    input_file_writer.close()
    return is_file_empty


def main(argv):

    try:

        is_infinite_loop = False
        # for arg in argv:
        # if arg == '-loop':
        #         is_infinite_loop = True
        #         break

        is_prod_machine = False
        for arg in argv:
            if arg == '-prod':
                is_prod_machine = True
                break
        if is_prod_machine:
            tp_common.settings['test_or_prod'] = tp_common.prod
            tp_mysql.read_write_mysql['test_or_prod'] = tp_mysql.prod
            tp_hive.target['test_or_prod'] = tp_hive.prod

        db_name_for_log_in_hive = tp_hive.target['test_or_prod']['hive_db']
        table_name_for_log_in_hive = tp_hive.target['test_or_prod']['hive_table']

        ################################################################################################################
        # prod_ or test_
        #
        target_folder_rel_path = tp_common.settings['test_or_prod']['target_folder_rel_path']
        target_dir_abs_path_in_tmp_in_fs = data.tmp_folder_abs_path_in_fs + target_folder_rel_path
        target_dir_abs_path_in_hdfs = data.model_folder_abs_path_in_hdfs + target_folder_rel_path
        target_dir_abs_path_in_http = http_config.server + http_config.arte_dir_abs_path + target_folder_rel_path
        target_prefix = target_folder_rel_path.strip()[:-1] + '_'

        logging.basicConfig(filename=log.dequeue['dir_abs_path'] +
                                     target_prefix +
                                     log.dequeue['file'],
                            level=log.dequeue['level'])

        run_yet = False
        while not run_yet:
            run_yet = True

            start_time = time.time()

            logging.info('')
            logging.info(' ===========================================================================================')
            logging.info(' The dequeue job starts at ' + epoch.get_current_time_up_to_second(start_time))
            logging.info(' ===========================================================================================')
            logging.info('')

            if is_prod_machine:
                logging.info(' This is for the production machine.')
            else:
                logging.info(' This is for the test machine.')

            logging.info(' Hence, the database, ' + tp_mysql.read_write_mysql['test_or_prod']['db'] + ', in ' +
                         tp_mysql.read_write_mysql['host'] + ' is used.')

            logging.info(' Going to ask enqueue2 to prepare the needed tables ...')
            enqueue2.main(sys.argv)
            logging.info(' Done running enqueue2 ...')

            ########################################
            # about to set up the MySQL connection #
            ########################################

            logging.info('')
            logging.info(' Setting up the connection to the database server ...')

            rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']
            rw_db_connect = MySQLdb.connect(tp_mysql.read_write_mysql['host'],
                                            file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                            file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                            rw_db)
            rw_db_connect.autocommit(False)
            cursor = rw_db_connect.cursor()

            algo_ids_in_pending_join_requests = []

            ############################################################################################################
            # all the following are based on this current time for tracking and organizing purpose
            #
            current_epoch_time = time.time()
            dt = epoch.get_current_time_up_to_date(current_epoch_time)
            dt_equal_to_dt_rel_path = 'dt=' + dt + '/'

            current_timestamp_up_to_hundredth_of_a_second = epoch.get_current_time_up_to_hundredth_of_a_second(
                current_epoch_time)
            current_timestamp_up_to_hundredth_of_a_second_prefix = current_timestamp_up_to_hundredth_of_a_second\
                                                                   + "_"
            current_timestamp_up_to_hundredth_of_a_second_dir_rel_path = current_timestamp_up_to_hundredth_of_a_second\
                                                                         + "/"
            current_timestamp_up_to_hundredth_of_a_second_dir_abs_path_in_tmp_in_fs = target_dir_abs_path_in_tmp_in_fs + \
                                                   current_timestamp_up_to_hundredth_of_a_second_dir_rel_path
            current_timestamp_up_to_hundredth_of_a_second_dir_abs_path_in_http = \
                target_dir_abs_path_in_http + \
                current_timestamp_up_to_hundredth_of_a_second_dir_rel_path

            the_global_resulting_timestamp_directory_abs_path_in_fs = \
                data.global_arte_folder_abs_path_in_fs + \
                target_folder_rel_path + \
                current_timestamp_up_to_hundredth_of_a_second_dir_rel_path

            logging.info('')
            logging.info(' *******************************************************************************************')
            logging.info(' ***   LOCK at ' + epoch.get_current_time_up_to_second(time.time()))
            logging.info(' *******************************************************************************************')
            logging.info('')

            try:
                select_pending_join_requests_statement = 'SELECT ' + \
                                                         'algo_id, ' + \
                                                         'MIN(create_ts) AS min_create_ts ' + \
                                                         'FROM ' + \
                                                         tp_mysql.read_write_join_requests_table['name'] + ' ' + \
                                                         'WHERE status = "pending" ' + \
                                                         'GROUP BY algo_id ' + \
                                                         'ORDER BY min_create_ts ASC ' + \
                                                         'FOR UPDATE'
                logging.info(
                    ' In db, ' + rw_db + ', executing the sql statement: ' + select_pending_join_requests_statement)
                cursor.execute(select_pending_join_requests_statement)

                for algo_id_and_min_create_ts in cursor:
                    algo_id_str = str(algo_id_and_min_create_ts[0])
                    min_create_ts_str = str(algo_id_and_min_create_ts[1])
                    logging.info('')
                    logging.info(' The earliest time that Algorithm ' + algo_id_str +
                                 ' \twas requested and still pending is at ' + min_create_ts_str)
                    algo_ids_in_pending_join_requests.append(algo_id_str)

                    # change pending to processing
                    #
                    update_join_request_status_given_cursor(rw_db, cursor, time.time(), algo_id_str,
                                                            PENDING_STATUS, PROCESSING_STATUS)

                logging.info('')
                logging.info(' Going to commit (i.e., release the lock)')
                rw_db_connect.commit()  # Note: commit (i.e., release the lock) right after select for update
            except:
                logging.info('')
                logging.info(' Going to rollback (i.e., release the lock)')
                rw_db_connect.rollback()  # Note: rollback (i.e., release the lock) if anything goes wrong
                logging.error(traceback.format_exc())
                update_join_request_status(rw_db, time.time(), algo_id_str, PENDING_STATUS,
                                           ERROR_STATUS_PREFIX + str(sys.exc_info()[0]))
                update_join_request_status(rw_db, time.time(), algo_id_str, PROCESSING_STATUS,
                                           ERROR_STATUS_PREFIX + str(sys.exc_info()[0]))
            cursor.close()

            logging.info('')
            logging.info(' *******************************************************************************************')
            logging.info(' *** UNLOCK at ' + epoch.get_current_time_up_to_second(time.time()))
            logging.info(' *******************************************************************************************')
            logging.info('')

            ############################################################################################################
            # used as string builder for one line for the to add log folder :)
            #
            timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log = \
                current_timestamp_up_to_hundredth_of_a_second

            valid_algo_id_exists = False
            valid_algo_id_count = 0;
            current_algo_id = ""

            logging.info(' The total number of the pending join requests that need to be processed is ' +
                         str(len(algo_ids_in_pending_join_requests)) + '.\n')

            if len(algo_ids_in_pending_join_requests) > 0:  # Note: JOIN in memory is not scalable >_<

                ########################################################################################################
                # (1/2) one side of the join ...
                #
                strategies_to_join = get_strategies_to_join_in_mysql(rw_db)
                strategy_id_and_algo_id_to_join______is_mapped_to______arte_min_bid_and_arte_max_bid = \
                    get_strategy_id_algo_id_to_arte_min_max_bids_mapping(strategies_to_join)

                logging.info('')
                logging.info(' (1/2) The total number of the strategies TO JOIN is ' +
                             str(len(strategies_to_join)) + '.')

                # loop through the pending algo ids to ensure if valid ...
                #
                for algo_id_in_pending_join_request in algo_ids_in_pending_join_requests:

                    ####################################################################################################
                    # end of the iteration
                    #
                    try:

                        logging.info('')
                        logging.info(' Processing the join'
                                     ' request for algorithm ' + algo_id_in_pending_join_request)

                        algo_id_valid = is_algo_id_valid(rw_db, algo_id_in_pending_join_request, is_prod_machine)

                        # we will never do the join if the algo is is not valid ...
                        #
                        if not algo_id_valid:
                            logging.info(" " + algo_id_in_pending_join_request + " is not a valid algo id to join >_<")
                            update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                       PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                                       "invalid ago id, " + algo_id_in_pending_join_request)
                            continue
                        else:
                            logging.info(" " + algo_id_in_pending_join_request + " is     a valid algo is to join ^O^")

                        ################################################################################################
                        # (2/2) the other side of the join ...
                        #
                        dimension_predictions_to_join, \
                        dimension_predictions_count = get_dimension_predictions_to_join(algo_id_in_pending_join_request)

                        if len(dimension_predictions_to_join) == dimension_predictions_count:
                            logging.info(' (2/2) The total number of the dimension predictions TO JOIN is ' +
                                         str(dimension_predictions_count))
                        else:
                            logging.error(' ERROR: The total number of the dimension predictions TO JOIN is'
                                          ' not matched with the count.')
                            raise ValueError(' ERROR: The total number of the dimension predictions TO JOIN is'
                                             ' not matched with the count.')  # sys.exit(-1)

                        ################################################################################################
                        # Up to this point, we have both sides of the JOIN (i.e., we are able to perform the join)
                        #
                        valid_algo_id_exists = True
                        valid_algo_id_count += 1
                        current_algo_id = algo_id_in_pending_join_request

                        algo_id_equal_to_algo_id_in_pending_join_request_rel_path = \
                            'algo_id=' + algo_id_in_pending_join_request + '/'

                        algo_dir_rel_path = algo.get[algo_id_in_pending_join_request]['algo_dir_rel_path']

                        logging.info('')
                        logging.info(' ************************************************************* About time to join'
                                     ' radiumone_master.STRATEGIES(' + str(len(strategies_to_join)) + ') with'
                                     ' adpred.arte_dimension_predictions(' + str(dimension_predictions_count) + ').')

                        mapping_function_abs_path_in_hdfs, \
                        timestamp_folder_abs_path_for_input_in_hdfs, \
                        timestamp_folder_abs_path_for_output_in_hdfs, \
                        timestamp_folder_abs_path_for_log_in_hdfs = \
                            pre_setup_for_hdfs(algo_id_in_pending_join_request,
                                               target_dir_abs_path_in_hdfs,
                                               algo_id_equal_to_algo_id_in_pending_join_request_rel_path,
                                               dt_equal_to_dt_rel_path,
                                               current_timestamp_up_to_hundredth_of_a_second_prefix)

                        mapping_function_abs_path_in_tmp_in_fs, \
                        input_fsv_abs_path_in_tmp_in_fs, \
                        output_tsv_abs_path_in_tmp_in_fs, \
                        output_log_abs_path_in_tmp_in_fs = \
                            pre_setup_tmp_for_fs(algo_id_in_pending_join_request,
                                                 target_dir_abs_path_in_tmp_in_fs,
                                                 algo_id_equal_to_algo_id_in_pending_join_request_rel_path,
                                                 dt_equal_to_dt_rel_path,
                                                 current_timestamp_up_to_hundredth_of_a_second_prefix)

                        ################################################################################################
                        # get the mapping func from hdfs ###############################################################
                        ################################################################################################

                        if file.does_file_exist(mapping_function_abs_path_in_tmp_in_fs):
                            file.remove(mapping_function_abs_path_in_tmp_in_fs)
                        hdfs.copy_to_local(mapping_function_abs_path_in_hdfs, mapping_function_abs_path_in_tmp_in_fs)

                        ################################################################################################
                        # get the input file for the mapping func ######################################################
                        ################################################################################################

                        is_file_empty = generate_input_from_join(
                            input_fsv_abs_path_in_tmp_in_fs,
                            algo_id_in_pending_join_request,
                            dimension_predictions_to_join,
                            strategy_id_and_algo_id_to_join______is_mapped_to______arte_min_bid_and_arte_max_bid,
                            dt,
                            current_timestamp_up_to_hundredth_of_a_second)

                        if file.does_file_exist(mapping_function_abs_path_in_tmp_in_fs):
                            if file.does_file_exist(input_fsv_abs_path_in_tmp_in_fs):
                                if not is_file_empty:

                                    ####################################################################################
                                    # have everything we need to get the output & log at this point ####################
                                    ####################################################################################

                                    logging.info(' ')
                                    logging.info(' Going to run the mapping func, ' +
                                                 mapping_function_abs_path_in_tmp_in_fs +
                                                 ', which requires the input file (i.e., the join result), ' +
                                                 input_fsv_abs_path_in_tmp_in_fs +
                                                 ', to be ready before running.')

                                    run_mapping_func(mapping_function_abs_path_in_tmp_in_fs,
                                                     input_fsv_abs_path_in_tmp_in_fs,
                                                     output_tsv_abs_path_in_tmp_in_fs,
                                                     output_log_abs_path_in_tmp_in_fs)

                                    logging.info(' ')
                                    logging.info(' After running the mapping func, the input, output, and log files are'
                                                 ' copied to the HDFS.')

                                    ####################################################################################
                                    # copy input, output, log to hdfs ##################################################
                                    ####################################################################################

                                    hdfs.copy_from_local(input_fsv_abs_path_in_tmp_in_fs,
                                                         timestamp_folder_abs_path_for_input_in_hdfs)
                                    hdfs.copy_from_local(output_tsv_abs_path_in_tmp_in_fs,
                                                         timestamp_folder_abs_path_for_output_in_hdfs)
                                    hdfs.copy_from_local(output_log_abs_path_in_tmp_in_fs,
                                                         timestamp_folder_abs_path_for_log_in_hdfs)

                                    logging.info(' ')
                                    logging.info(' Going to refresh ' +
                                                 db_name_for_log_in_hive + "." + table_name_for_log_in_hive +
                                                 " in hive.")

                                    hive.refresh_table(db_name_for_log_in_hive, table_name_for_log_in_hive)

                                    ####################################################################################
                                    # form a temp algo dir #############################################################
                                    ####################################################################################

                                    file.create_folder_if_not_exists(
                                        current_timestamp_up_to_hundredth_of_a_second_dir_abs_path_in_tmp_in_fs[:-1])

                                    target_algorithm_directory_parent_abs_path_in_tmp_in_fs = \
                                        current_timestamp_up_to_hundredth_of_a_second_dir_abs_path_in_tmp_in_fs + \
                                        algo_id_equal_to_algo_id_in_pending_join_request_rel_path

                                    file.create_folder_if_not_exists(
                                        target_algorithm_directory_parent_abs_path_in_tmp_in_fs[:-1])

                                    template_algo_dir_abs_path_in_fs = algo.template_src_folder_abs_path_in_fs + \
                                                                       target_folder_rel_path + algo_dir_rel_path
                                    file.copy_recursively(template_algo_dir_abs_path_in_fs,
                                                          target_algorithm_directory_parent_abs_path_in_tmp_in_fs)

                                    target_algorithm_directory_abs_path_in_tmp_in_fs = \
                                        target_algorithm_directory_parent_abs_path_in_tmp_in_fs + algo_dir_rel_path
                                    target_algorithm_directory_output_tsv_des_file_path_in_tmp_in_fs = \
                                        target_algorithm_directory_abs_path_in_tmp_in_fs + \
                                        data.data_folder_rel_path + \
                                        data.output_file
                                    file.copy(output_tsv_abs_path_in_tmp_in_fs,
                                              target_algorithm_directory_output_tsv_des_file_path_in_tmp_in_fs)

                                    ####################################################################################
                                    # copy temp one to some global area as record ######################################
                                    ####################################################################################

                                    file.create_folder_if_not_exists(
                                        the_global_resulting_timestamp_directory_abs_path_in_fs)

                                    the_global_resulting_algorithm_directory_abs_path_in_fs = \
                                        the_global_resulting_timestamp_directory_abs_path_in_fs + \
                                        algo_id_equal_to_algo_id_in_pending_join_request_rel_path + \
                                        algo_dir_rel_path

                                    file.create_folder_if_not_exists(
                                        the_global_resulting_algorithm_directory_abs_path_in_fs)

                                    file.copy_recursively2(target_algorithm_directory_abs_path_in_tmp_in_fs,
                                                           the_global_resulting_algorithm_directory_abs_path_in_fs)

                                    ####################################################################################
                                    # copy temp one to http server #####################################################
                                    ####################################################################################

                                    # compress
                                    #
                                    tgz_file_name = algo_dir_rel_path[:-1] + ".tgz"
                                    logging.info(' Compressing everything in the algo dir, ' +
                                                 target_algorithm_directory_abs_path_in_tmp_in_fs +
                                                 ', as ' + tgz_file_name)
                                    compressed_file_abs_path_in_fs = file.compress(
                                        os.getcwd(),
                                        target_algorithm_directory_parent_abs_path_in_tmp_in_fs, algo_dir_rel_path,
                                        tgz_file_name)
                                    logging.info(' The compressed file is ' + compressed_file_abs_path_in_fs + "\n")

                                    # upload
                                    #
                                    logging.info(" Uploading " + compressed_file_abs_path_in_fs + " to " +
                                                 current_timestamp_up_to_hundredth_of_a_second_dir_abs_path_in_http)
                                    logging.info('')
                                    http.upload(current_timestamp_up_to_hundredth_of_a_second_dir_abs_path_in_http,
                                                compressed_file_abs_path_in_fs)

                                    # complete
                                    #
                                    logging.info(" Completing the dequeue work for the algo id, " +
                                                 algo_id_in_pending_join_request + "\n")
                                    update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                               PROCESSING_STATUS, COMPLETE_STATUS)
                                else:
                                    update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                               PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                                               "empty input file for " + algo_id_in_pending_join_request)
                            else:
                                update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                           PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                                           "missing the input file for " + algo_id_in_pending_join_request)
                        else:  # Good. A nice message :)
                            update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                       PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                                       "missing the mapping func for " + algo_dir_rel_path)
                        timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log += \
                        ',' + algo_dir_rel_path[:-1] + ".tgz"

                    except:
                        logging.error('')
                        logging.error('unexpected error: ' + str(sys.exc_info()[0]))
                        logging.error(traceback.format_exc())
                        update_join_request_status(rw_db, time.time(), algo_id_in_pending_join_request,
                                                   PROCESSING_STATUS, ERROR_STATUS_PREFIX +
                                                   "probably due to hive connection to " + tp_hive.host + ":" +
                                                   tp_hive.port + " (try it again in the next round)")
                        enqueue.enqueue(current_algo_id, time.time())  # re-enqueue if due to hive related stuffs ...
                    #
                    # end of the iteration
                    ####################################################################################################

            if valid_algo_id_exists:

                ########################################################################################################
                # finally, log it in http server #######################################################################
                ########################################################################################################

                target_to_add_file_name = target_prefix + http_config.to_add_log_file_name
                http_server_to_add_log_host_abs_path = target_dir_abs_path_in_http + target_to_add_file_name
                logging.info(' Going to log "' + timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log +
                             '" to ' + http_server_to_add_log_host_abs_path)
                local_to_add_log_abs_path = http.download(http_server_to_add_log_host_abs_path, target_to_add_file_name)
                if file.contain(local_to_add_log_abs_path, http.ERROR_CODE_NOT_FOUND):
                    file.empty(local_to_add_log_abs_path)
                file.append2(local_to_add_log_abs_path,
                             timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log)
                http.upload(target_dir_abs_path_in_http, local_to_add_log_abs_path)

            logging.info(' Out of ' + str(len(algo_ids_in_pending_join_requests)) + ' algo id(s), ' +
                         str(valid_algo_id_count) +
                         " of them is/are valid.")

            suc_count = timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log.count(',')

            logging.info(' Out of ' + str(valid_algo_id_count) + ' valid algo id(s), ' +
                         str(suc_count) +
                         " of them are processed successfully.")

            if valid_algo_id_exists:
                logging.info(' They are ' + timestamp_and_algorithm_directories_in_csv_for_http_server_to_add_log)

            logging.info(' Note: check the ' +
                         db_name_for_log_in_hive + '.' +
                         table_name_for_log_in_hive + ' table to the failure info ...')

            end_time = time.time()
            logging.info('')
            logging.info(' ===========================================================================================')
            if valid_algo_id_count > 0:
                logging.info(' The average time per algo id is '+str((end_time-start_time)/valid_algo_id_count)+' seconds.')
            else:
                logging.info(' There are NO valid algo ids.')
            logging.info(' The dequeue job ends at ' + epoch.get_current_time_up_to_second(end_time))
            logging.info(' The dequeue job elapsed time is ' + str(end_time - start_time) + ' seconds.')
            logging.info(' ===========================================================================================')
            logging.info('')

            if is_infinite_loop:
                run_yet = False
                time.sleep(1000)

    except:
        logging.error('')
        logging.error(' Unexpected error: ' + str(sys.exc_info()[0]))
        logging.error(traceback.format_exc())
        sys.exit(-1)

if __name__ == '__main__':
    main(sys.argv)