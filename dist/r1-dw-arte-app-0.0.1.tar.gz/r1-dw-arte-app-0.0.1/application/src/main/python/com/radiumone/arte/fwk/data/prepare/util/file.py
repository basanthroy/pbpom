__author__ = 'cliu'

import os


def contain(file_abs_path, tgt_str):
    found = False
    f = open(file_abs_path)
    for line in f:
        if tgt_str in line:
            found = True
            break
    f.close()
    return found


def empty(file_abs_path):
    open(file_abs_path, 'w').close()


def prepend(file_abs_path, line, delimit):
    f = open(file_abs_path)
    text = f.read()
    f.close()
    f = open(file_abs_path, 'w')
    f.write(line + delimit)
    f.write(text)
    f.close()


def prepend2(file_abs_path, line):
    prepend(file_abs_path, line, '\n')


def append(file_abs_path, line, delimit):
    f = open(file_abs_path, 'a')
    f.write(line + delimit)
    f.close()


def append2(file_abs_path, line):
    append(file_abs_path, line, '\n')


def compress(current_working_dir_abs_path, parent_of_algo_dir_abs_path, algo_dir_rel_path, rslt_tgz_file_name):
    os.chdir(parent_of_algo_dir_abs_path)
    os.system("tar -cvzf " + rslt_tgz_file_name + " " + algo_dir_rel_path + "*")
    os.chdir(current_working_dir_abs_path)
    return parent_of_algo_dir_abs_path + rslt_tgz_file_name


def decompress(give_tgz_file_abs_path):
    os.system("tar -zxvf " + give_tgz_file_abs_path)
    return give_tgz_file_abs_path[:-1*len('.tgz')]


def remove_recursively(file_or_directory_abs_path):
    os.system('rm -rf ' + file_or_directory_abs_path)


def remove(file_abs_path):
    os.system("rm " + file_abs_path)


def move(src_dir_path, dst_dir_path):
    os.system('mv ' + src_dir_path + ' ' + dst_dir_path)


def touch(abs_path):
    os.system('touch ' + abs_path)


def copy_recursively(src_dir_abs_path, tgt_dir_abs_path):
    os.system("cp -p -r " + src_dir_abs_path + " " + tgt_dir_abs_path)


def copy_recursively2(src_dir_abs_path, tgt_dir_abs_path):
    os.system("cp -p -r " + src_dir_abs_path + "* " + tgt_dir_abs_path)


def copy(src_abs_path, tgt_abs_path):
    os.system("cp -p " + src_abs_path + " " + tgt_abs_path)


def does_file_exist(file_path):
    return os.path.isfile(file_path)


def does_dir_exist(dir_path):
    return os.path.isdir(dir_path)


def create_folder_if_not_exists(directory):
    if not os.path.exists(directory):
        os.makedirs(directory)


def set_file_one_line(file_path, h):
    open(file_path, 'w').write(h)


def get_file_one_line(file_path):
    if not does_file_exist(file_path):
        set_file_one_line(file_path, '')
    return open(file_path, 'r').readline().strip()


def replace(file_abs_path, old_data, new_data):
    f = open(file_abs_path, 'r')
    data_before_replace = f.read()
    f.close()
    data_after_replace = data_before_replace.replace(old_data, new_data)
    f = open(file_abs_path, 'w')
    f.write(data_after_replace)
    f.close()