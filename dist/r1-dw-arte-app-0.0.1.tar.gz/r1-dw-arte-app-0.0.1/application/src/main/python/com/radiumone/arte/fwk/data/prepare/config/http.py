__author__ = 'cliu'

server                              = 'http://jobserver2.dw.sc.gwallet.com'
arte_dir_abs_path                   = '/arte/'
to_add_log_file_name                = 'toAdd.log'
to_add_last_download_time_file_name = 'toAdd.last'
