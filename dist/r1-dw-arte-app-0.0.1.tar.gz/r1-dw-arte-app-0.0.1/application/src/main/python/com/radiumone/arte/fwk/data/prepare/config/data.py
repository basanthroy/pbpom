__author__ = 'cliu'

global_arte_folder_abs_path_in_fs = '/tmp/arte/app/data_prepare/'  # happened to under /tmp, but not necessary so ...

tmp_folder_abs_path_in_fs = '/tmp/arte/app/data_prepare/tmp/'  # used to hold the last upload !!!

model_folder_abs_path_in_hdfs = '/user/arteu/model/'

func_folder_rel_path = 'func/'
input_folder_rel_path = 'input/'
output_folder_rel_path = 'output/'
log_folder_rel_path = 'log/'
data_folder_rel_path = 'data/'

input_file = 'input.fsv'
output_file = 'output.tsv'  # (un)load.sh must use this file name
#schema_file = 'output_type.tsv'  # (un)load.sh must use this file name
log_file = 'output_log.json'