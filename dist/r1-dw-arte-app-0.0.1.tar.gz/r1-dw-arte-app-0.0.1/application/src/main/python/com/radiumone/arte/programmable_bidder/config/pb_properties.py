__author__ = 'broy'

ROOT_DIR='/opt/dwradiumone/arte/programmable_bidder'
