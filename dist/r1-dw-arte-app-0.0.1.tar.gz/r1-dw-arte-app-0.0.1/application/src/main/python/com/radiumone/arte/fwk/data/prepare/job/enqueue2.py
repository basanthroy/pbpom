__author__ = 'cliu'


import enqueue
import logging
import sys
import time
import traceback

from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import log
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_common
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_hash
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_mysql
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import file
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import hash
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import mysql
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import epoch
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import helper


def get_current_strategies(db):
    logging.info('')
    logging.info(' Going to get the currently cached strategies ...')
    select_statement = 'SELECT ' + \
                       tp_mysql.read_write_strategies_table['columns'] + ' ' \
                       'FROM ' + \
                       tp_mysql.read_write_strategies_table['tmp_name']
    logging.info(' In db, ' + db + ', executing the sql statement: ' + select_statement)
    return mysql.run_sql_with_db(tp_mysql.read_write_mysql['host'],
                                 file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                 file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                 db,
                                 select_statement)


def get_modified_strategies(db, pre_strategies_table, cur_strategies_table):
    logging.info('')

    select_statement = 'SELECT ' \
                       'current.strategy_id, current.max_bid, current.min_bid, current.algo_id' + ' ' \
                       'FROM ' + \
                       cur_strategies_table + ' current, ' + \
                       pre_strategies_table + ' previous ' + \
                       'WHERE current.strategy_id = previous.strategy_id AND ' + \
                       '(' + \
                           '(' + \
                               'current.max_bid != previous.max_bid ' + \
                               'OR ' + \
                               '(current.max_bid IS NULL AND previous.max_bid IS NOT NULL) ' + \
                               'OR ' + \
                               '(current.max_bid IS NOT NULL AND previous.max_bid IS NULL)' + \
                           ') ' + \
                       'OR  ' + \
                               '(' + \
                               'current.min_bid != previous.min_bid ' + \
                               'OR ' + \
                               '(current.min_bid IS NULL AND previous.min_bid IS NOT NULL) ' + \
                               'OR ' + \
                               '(current.min_bid IS NOT NULL AND previous.min_bid IS NULL)' + \
                           ')' + \
                       ')'
    logging.info(' In db, ' + db + ', executing the sql statement: ' + select_statement)
    return mysql.run_sql_with_db(tp_mysql.read_write_mysql['host'],
                                 file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                 file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                 db,
                                 select_statement)  # TODO: a possible improvement is to cache the hash of each row ...


def get_newly_created_strategies(db, pre_strategies_table, cur_strategies_table):
    logging.info('')

    select_statement = 'SELECT ' \
                       'current.strategy_id, current.max_bid, current.min_bid, current.algo_id' + ' ' \
                        'FROM ' + \
                        cur_strategies_table + ' current ' + \
                        'LEFT JOIN ' + \
                        pre_strategies_table + ' previous ' + \
                        'ON current.strategy_id = previous.strategy_id ' + \
                        'WHERE previous.strategy_id IS NULL'
    logging.info(' In db, ' + db + ', executing the sql statement: ' + select_statement)
    return mysql.run_sql_with_db(
                        tp_mysql.read_write_mysql['host'],
                        file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                        file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                        db,
                        select_statement)


def drop_table(db, pre_strategies_table):
    logging.info('')

    drop_statement = 'DROP TABLE ' + \
                     pre_strategies_table
    logging.info(' In db, ' + db + ', executing the sql statement: ' + drop_statement)
    mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                      file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                      file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                      db,
                                      drop_statement)


def set_previous_with_current(db, pre_strategies_table, cur_strategies_table):
    logging.info('')

    create_statement = 'CREATE TABLE ' + \
                       pre_strategies_table + ' ' + \
                       'AS SELECT * FROM ' + \
                       cur_strategies_table
    logging.info(' In db, ' + db + ', executing the sql statement: ' + create_statement)
    mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                      file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                      file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                      db,
                                      create_statement)


def get_update_statement_for_previous_strategies_table(pre_strategies_table, algo_id_str, strategy_id_str, max_bid_str,
                                                       min_bid_str):
    return 'UPDATE ' + pre_strategies_table + \
           ' SET ' + \
           'max_bid = ' + max_bid_str + ', ' + \
           'min_bid = ' + min_bid_str + ', ' + \
           'algo_id = ' + algo_id_str + ' WHERE strategy_id = ' + strategy_id_str


def get_insert_statement_for_previous_strategies_table(pre_strategies_table, algo_id_str, strategy_id_str, max_bid_str,
                                                       min_bid_str):
    return 'INSERT INTO ' + pre_strategies_table + \
           ' ( ' + \
           tp_mysql.read_write_strategies_table['columns'] + \
           ' ) ' + \
           'VALUES (' + \
           strategy_id_str + ', ' + \
           max_bid_str + ', ' + \
           min_bid_str + ', ' + \
           algo_id_str + ')'


def run(db, sql_statement):
    logging.info(' In db, ' + db + ', executing the sql statement: ' + sql_statement)
    mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                      file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                      file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                      db,
                                      sql_statement)


def main(argv):

    is_infinite_loop = False
    # for arg in sys.argv:
    #     if arg == '-loop':
    #         is_infinite_loop = True
    #         break

    is_prod_machine = False  # unless specified through -prod. otherwise, treated as test.
    for arg in argv:
        if arg == '-prod':
            is_prod_machine = True
            break

    if is_prod_machine:
        tp_common.settings['test_or_prod'] = tp_common.prod
        tp_mysql.read_write_mysql['test_or_prod'] = tp_mysql.prod
        tp_hash.target['test_or_prod'] = tp_hash.prod

    logging.basicConfig(filename=log.enqueue2['dir_abs_path'] +
                                 tp_common.settings['test_or_prod']['target_folder_rel_path'].strip()[:-1] + '_' +
                                 log.enqueue2['file'],
                        level=log.enqueue2['level'])

    run_yet = False
    while not run_yet:
        run_yet = True

        start_time = time.time()

        logging.info('')
        logging.info(' %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
        logging.info(' The enqueue2 job starts at ' + epoch.get_current_time_up_to_second(start_time))
        logging.info(' %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
        logging.info('')

        if is_prod_machine:
            logging.info(' This is for the production machine.')
        else:
            logging.info(' This is for the test machine.')
        logging.info(' Hence, the database, ' + tp_mysql.read_write_mysql['test_or_prod']['db'] + ', in ' +
                     tp_mysql.read_write_mysql['host'] + ' is used.')

        enqueue.init()  # TODO: revisit it once the radiumone_master.strategies has algo_id column !!!

        ################################################################################################################
        # The differences from enqueue.py begin here ###################################################################
        ################################################################################################################

        rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']
        previous_strategies_table = tp_mysql.read_write_strategies_table['previous']
        current_strategies_table = tp_mysql.read_write_strategies_table['tmp_name']

        does_previous_table_exist = True
        is_previous_table_out_of_date = True

        algorithm_ids = set()  # Note: The reason why using set, not [], is
        #                              because multiple strategies might be mapped to the same algorithm id.

        previous_hash_file_name = tp_hash.target['test_or_prod']['hash_file']
        current_hash = ''

        try:

            strategies = get_current_strategies(rw_db)
            logging.info(' At most ' + str(len(strategies)) + ' join requests will be sent. (Note: Among them,'
                         ' we still need to find out the modified ones and the newly created ones !!!)')
            logging.info('')

            if len(strategies) > 0:

                strategies_str = helper.convert_list_of_list_to_string(strategies)
                current_hash = str(hash.compute_hash(tp_hash.hash_method, strategies_str))
                logging.info(' The current  hash is "' + current_hash + '".')

                previous_hash = file.get_file_one_line(previous_hash_file_name)
                logging.info(' The previous hash is "' + previous_hash + '".')

                if current_hash == previous_hash:
                    logging.info(' Everything remains the same :)')
                    logging.info('')
                    is_previous_table_out_of_date = False
                else:
                    logging.info(' Something has changed :(')
                    logging.info('')

                    ####################################################################################################
                    # Prepare the requests #############################################################################
                    ####################################################################################################

                    if not mysql.does_table_exist(tp_mysql.read_write_mysql['host'],
                                                  file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                                  file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                                  rw_db,
                                                  previous_strategies_table):
                        logging.info(' The table, ' + previous_strategies_table + ','
                                     ' does not exist in database, ' + rw_db + ', yet.')
                        does_previous_table_exist = False

                        for strategy in strategies:
                            algo_id = strategy[3]
                            algorithm_ids.add(algo_id)
                    else:
                        logging.info(' The table, ' + previous_strategies_table + ','
                                     ' already existed in database, ' + rw_db + '.')

                        #######################################################################
                        # PREVIOUS VS CURRENT = MODIFIED & NEWLY CREATED (IGNORE THE DELETED) #
                        #######################################################################

                        modified_strategies_as_list_of_list = get_modified_strategies(
                            rw_db,
                            previous_strategies_table,
                            current_strategies_table)

                        logging.info(' The number of strategies being modified is ' +
                                     str(len(modified_strategies_as_list_of_list)))

                        for modified_strategy in modified_strategies_as_list_of_list:
                            algo_id = modified_strategy[3]
                            algorithm_ids.add(algo_id)  # gathering the request (2/3): subset of strategies will be sent

                        newly_created_strategies_as_list_of_list = get_newly_created_strategies(
                            rw_db,
                            previous_strategies_table,
                            current_strategies_table)

                        logging.info(' The number of strategies being created is ' +
                                     str(len(newly_created_strategies_as_list_of_list)))

                        for newly_created_strategy in newly_created_strategies_as_list_of_list:
                            algo_id = newly_created_strategy[3]
                            algorithm_ids.add(algo_id)  # gathering the request (3/3): subset of strategies will be sent

        except:
            traceback.print_exc(file=sys.stdout)

            logging.error("enqueue2's unexpected error: " + str(sys.exc_info()[0]))
            raise  # sys.exit(-1)

        ################################################################################################################
        # sending requests #############################################################################################
        ################################################################################################################

        logging.info('')
        current_epoch_time = time.time()
        succ_count = 0
        request_count = 1
        for algorithm_id in algorithm_ids:
            logging.info(' Sending request ' + str(request_count) + ': ')
            enqueue.enqueue(algorithm_id, current_epoch_time)
            succ_count += 1
            logging.info(" The algorithm id, " + algorithm_id + ", had been enqueue-ed SUCCESSFULLY :)")
            request_count += 1

        ################################################################################################################
        # update the previous at the end (i.e., below) #################################################################
        ################################################################################################################

        if not does_previous_table_exist:
            logging.info(" The previously cached strategies didn't exist yet. Creating one now ...")
            set_previous_with_current(rw_db, previous_strategies_table, current_strategies_table)
        elif is_previous_table_out_of_date:
            logging.info(" The previously cached strategies are out of date. Refresh ...")
            drop_table(rw_db, previous_strategies_table)
            set_previous_with_current(rw_db, previous_strategies_table, current_strategies_table)
        else:
            logging.info(" The previously cached strategies are still valid ...")

        logging.info(' ' + previous_hash_file_name + ' has "' + current_hash + '" now.')
        file.set_file_one_line(previous_hash_file_name, current_hash)

        logging.info('')
        logging.info(' Out of ' + str(len(algorithm_ids)) + ', ' + str(succ_count) + ' of them SUCCEEDED.')

        end_time = time.time()
        logging.info('')
        logging.info(' %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
        logging.info(' The enqueue2 job ends at ' + epoch.get_current_time_up_to_second(end_time))
        logging.info(' The enqueue2 job elapsed time is ' + str(end_time - start_time) + ' seconds.')
        logging.info(' %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%')
        logging.info('')

        if is_infinite_loop:
            run_yet = False
            time.sleep(10000)

if __name__ == '__main__':

    sys.exit(main(sys.argv))