__author__ = 'cliu'

enqueue = {'dir_abs_path': '/tmp/',
           'file': 'enqueue.log',
           'level': 'INFO'}

enqueue2 = {'dir_abs_path': '/tmp/',
            'file': 'enqueue2.log',
            'level': 'INFO'}

dequeue = {'dir_abs_path': '/tmp/',
           'file': 'dequeue.log',
           'level': 'INFO'}

deploy = {'dir_abs_path': '/tmp/',
          'file': 'deploy.log',
          'level': 'INFO'}