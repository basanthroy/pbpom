__author__ = 'cliu'

import logging
import sys
import pyhs2
import time

from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import log
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import mysql2
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_common
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_hive
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.config import tp_mysql
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import file
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import mysql
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import epoch
from application.src.main.python.com.radiumone.arte.fwk.data.prepare.util import helper


def create_table_in_read_write_mysql_tmp_strategies_from_strategies_table_in_read_only_mysql(bulk_insert_size):
    logging.info('')

    ro_db = tp_mysql.read_only_strategies_table['db']

    select_statement = 'SELECT ' + \
                       tp_mysql.read_only_strategies_table['tmp_columns'] + ' ' \
                       'FROM ' + \
                       tp_mysql.read_only_strategies_table['name']  # TODO: where arte is enabled...
    logging.info(' In db, ' + ro_db + ', executing the sql statement: ' + select_statement)
    raw_strategies = mysql.run_sql_with_db(tp_mysql.read_only_mysql['host'],
                                           file.get_file_one_line(tp_mysql.read_only_mysql['user']),
                                           file.get_file_one_line(tp_mysql.read_only_mysql['passwd']),
                                           ro_db,
                                           select_statement)

    rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']

    create_statement = tp_mysql.read_only_strategies_table['tmp_create_statement']
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + create_statement)
    mysql.create_table_if_not_exists(tp_mysql.read_write_mysql['host'],
                                     file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                     file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                     rw_db,
                                     tp_mysql.read_only_strategies_table['tmp_name'],
                                     create_statement)

    delete_statement = 'DELETE FROM ' + tp_mysql.read_only_strategies_table['tmp_name']
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + delete_statement)
    mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                      file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                      file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                      rw_db,
                                      delete_statement)

    strategies = []

    #
    # Note: raw_strategies might contain the ones that need to be filtered out.
    #       For example, the ones whose bid prices are NULL. (suggested by Randall)
    #

    num_of_columns = 3  # TODO: set to 4 once algo_id is provided !!!
    for raw_strategy in raw_strategies:

        if len(raw_strategy) != num_of_columns:
            logging.error('each strategy must have ' + str(num_of_columns) + ' columns: ' +
                          tp_mysql.read_only_strategies_table['tmp_columns'])
            raise ValueError('each strategy must have ' + str(num_of_columns) + ' columns: ' +
                          tp_mysql.read_only_strategies_table['tmp_columns'])  # sys.exit(-1)

        raw_strategy_id = raw_strategy[0]
        raw_arte_max_bid = helper.if_none_then_set_to_null(raw_strategy[1])
        raw_arte_min_bid = helper.if_none_then_set_to_null(raw_strategy[2])

        if raw_arte_max_bid == 'NULL' or raw_arte_min_bid == 'NULL':
            logging.debug(' The strategy whose strategy_id is ' + raw_strategy_id + ' is filtered out'
                          ' since its max/min bids are ' + raw_arte_max_bid + '/' + raw_arte_min_bid + '.'
                          ' (Note: Both max bid and min bid must be non-NULL.)')
        else:
            strategies.append(raw_strategy)

    #
    # Note: Prepare to insert what we have so far from the read-only mysql to the read-write mysql :D
    #

    insert_statement_prefix = "INSERT INTO " + \
                              tp_mysql.read_only_strategies_table['tmp_name'] + \
                              "(" + \
                              tp_mysql.read_only_strategies_table['tmp_columns'] + \
                              ") VALUES "

    insert_statement_builder = [insert_statement_prefix]

    row_count = 1
    for strategy in strategies:

        if len(strategy) != num_of_columns:
            err_message = 'each strategy should only have ' + str(num_of_columns) + ' columns: ' + \
                          tp_mysql.read_only_strategies_table['tmp_columns']
            logging.error(err_message)
            raise ValueError(err_message)

        strategy_id = strategy[0]
        arte_max_bid = helper.if_none_then_set_to_null(strategy[1])
        arte_min_bid = helper.if_none_then_set_to_null(strategy[2])

        if arte_max_bid == 'NULL' or arte_min_bid == 'NULL':
            err_message = ' The strategy whose strategy_id is ' + strategy_id + ' is not filtered out yet' + \
                          ' since its max/min bids are ' + raw_arte_max_bid + '/' + raw_arte_min_bid + '.' + \
                          ' (Note: Both max bid and min bid must be non-NULL and it should be filtered out already.)'
            logging.error(err_message)
            raise ValueError(err_message)
        #
        # Note: If last or every BULK insert size reached, do it.
        #
        if row_count == len(strategies) or row_count % bulk_insert_size == 0:
            entry = '(' + \
                    strategy_id + ', ' + \
                    arte_max_bid + ', ' + \
                    arte_min_bid + ')'
            insert_statement_builder.append(entry)

            insert_statement = ''.join(insert_statement_builder)
            logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + insert_statement)
            mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                              file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                              file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                              rw_db,
                                              insert_statement)

            insert_statement_builder = [insert_statement_prefix]
        else:
            entry = '(' + \
                    strategy_id + ', ' + \
                    arte_max_bid + ', ' + \
                    arte_min_bid + '),'
            insert_statement_builder.append(entry)
            row_count += 1

    logging.info(' Out of ' + str(len(raw_strategies)) + ' strategies,'
                 ' only ' + str(len(strategies)) + ' of them are being inserted.')

    if row_count != len(strategies):
        logging.error(' We have ' + str(len(strategies)) + ' strategies to insert,'
                      ' but we only insert ' + str(row_count) + ' of them.')
        raise ValueError(' We have ' + str(len(strategies)) + ' strategies to insert,'
                         ' but we only insert ' + str(row_count) + ' of them.')
    else:
        logging.info(' We have successfully insert ' + str(row_count) + ' strategies.')


def create_table_in_read_write_mysql_strategies():  # Note: It has all the columns needed including algo_id !!!
    logging.info('')

    rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']

    create_statement = tp_mysql.read_write_strategies_table['create_statement']
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + create_statement)
    mysql.create_table_if_not_exists(tp_mysql.read_write_mysql['host'],
                                     file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                     file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                     rw_db,
                                     tp_mysql.read_write_strategies_table['name'],
                                     create_statement)

    delete_statement = 'DELETE FROM ' + tp_mysql.read_write_strategies_table['name']
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + delete_statement)
    mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                      file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                      file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                      rw_db,
                                      delete_statement)


def create_table_in_read_write_mysql_tmp_strategy_to_algo():
    logging.info('')

    rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']

    create_statement = mysql2.read_write_tmp_strategy_to_algo_table['create_statement']
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + create_statement)
    mysql.create_table_if_not_exists(tp_mysql.read_write_mysql['host'],
                                     file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                     file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                     rw_db,
                                     mysql2.read_write_tmp_strategy_to_algo_table['name'],
                                     create_statement)

    delete_statement = 'DELETE FROM ' + mysql2.read_write_tmp_strategy_to_algo_table['name']
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + delete_statement)
    mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                      file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                      file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                      rw_db,
                                      delete_statement)


def insert_table_in_read_write_mysql_some_mapping_into_tmp_strategy_to_algo():

    logging.info('')

    select_distinct_strategy_id_and_algo_id = \
        'select distinct strategy_id, algo_id from adpred.arte_dimension_predictions'

    logging.info('')
    logging.info(" Getting data from hive ...")
    start_time = time.time()

    strategy_ids_and_algo_ids = []

    with pyhs2.connect(host=tp_hive.host,
                       user=file.get_file_one_line(tp_hive.user),
                       password=file.get_file_one_line(tp_hive.passwd),
                       port=tp_hive.port,
                       authMechanism=tp_hive.authMechanism
                      ) as conn:
        with conn.cursor() as cur:
            logging.info('')
            logging.info(' In host, ' + tp_hive.host + ', executing the hql statement: ' +
                         select_distinct_strategy_id_and_algo_id)
            cur.execute(select_distinct_strategy_id_and_algo_id)
            for i in cur.fetch():
                strategy_ids_and_algo_ids.append(i)
            cur.close()
            logging.info('')

    rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']

    end_time = time.time()
    logging.info(' The hive data retrieval took ' + str(end_time - start_time) + ' seconds.')

    for strategy_id_and_algo_id in strategy_ids_and_algo_ids:
        insert_statement = 'INSERT INTO ' + \
                           mysql2.read_write_tmp_strategy_to_algo_table['name'] + \
                           '(' + \
                           mysql2.read_write_tmp_strategy_to_algo_table['columns'] + \
                           ') ' + \
                           'VALUES (' + str(strategy_id_and_algo_id[0]) + ', ' + str(strategy_id_and_algo_id[1]) + ')'
        logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + insert_statement)
        mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                          file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                          file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                          rw_db,
                                          insert_statement)


def create_view__in_read_write_mysql_tmp_strategies_view():
    logging.info('')

    rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']

    create_statement = mysql2.read_write_tmp_strategy_view['create_statement']
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + create_statement)
    mysql.create_table_if_not_exists(tp_mysql.read_write_mysql['host'],
                                     file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                     file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                     rw_db,
                                     mysql2.read_write_tmp_strategy_view['name'],
                                     create_statement)


def create_table_in_read_write_mysql_join_requests():
    logging.info('')

    rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']

    create_statement = tp_mysql.read_write_join_requests_table['create_statement']
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + create_statement)
    mysql.create_table_if_not_exists(tp_mysql.read_write_mysql['host'],
                                     file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                     file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                     rw_db,
                                     tp_mysql.read_write_join_requests_table['name'],
                                     create_statement)


def init():

    create_table_in_read_write_mysql_tmp_strategies_from_strategies_table_in_read_only_mysql(10000)

    create_table_in_read_write_mysql_strategies()
    create_table_in_read_write_mysql_tmp_strategy_to_algo()
    insert_table_in_read_write_mysql_some_mapping_into_tmp_strategy_to_algo()
    create_view__in_read_write_mysql_tmp_strategies_view()
    create_table_in_read_write_mysql_join_requests()


def is_valid_algo_id(algo_id):
    logging.debug('')

    rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']

    select_statement = 'SELECT * FROM ' + \
                       tp_mysql.read_write_strategies_table['tmp_name'] + ' ' + \
                       'WHERE algo_id = ' + \
                       str(algo_id)
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + select_statement)
    strategies = mysql.run_sql_with_db(tp_mysql.read_write_mysql['host'],
                                       file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                       file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                       rw_db,
                                       select_statement
                                       )
    if len(strategies) > 0:
        return True
    return False


def enqueue(algo_id, current_epoch_time):
    logging.debug('')

    rw_db = tp_mysql.read_write_mysql['test_or_prod']['db']

    current_time_up_to_hundredth_of_a_second = epoch.get_current_time_up_to_hundredth_of_a_second(current_epoch_time)

    insert_statement = 'INSERT INTO ' + \
                       tp_mysql.read_write_join_requests_table['name'] + '(' + \
                       tp_mysql.read_write_join_requests_table['columns'] + ') VALUES (' + \
                       current_time_up_to_hundredth_of_a_second + ', ' + \
                       algo_id + ', ' + \
                       current_time_up_to_hundredth_of_a_second + ', ' + \
                       '"pending")'
    logging.info(' In db, ' + rw_db + ', executing the sql statement: ' + insert_statement)
    mysql.run_sql_with_db_with_commit(tp_mysql.read_write_mysql['host'],
                                      file.get_file_one_line(tp_mysql.read_write_mysql['user']),
                                      file.get_file_one_line(tp_mysql.read_write_mysql['passwd']),
                                      rw_db,
                                      insert_statement)


def main(argv):

    logging.basicConfig(filename=log.enqueue['dir_abs_path'] +
                                 tp_common.settings['test_or_prod']['target_folder_rel_path'].strip()[:-1] + '_' +
                                 log.enqueue['file'],
                        level=log.enqueue['level'])
    logging.info('')

    start_time = time.time()

    logging.info('')
    logging.info(' ===========================================')
    logging.info(' The enqueue job starts at ' + epoch.get_current_time_up_to_second(start_time))
    logging.info(' ===========================================')
    logging.info('')

    is_prod_machine = False  # unless specified through -prod. otherwise, treated as test.
    for arg in argv:
        if arg == '-prod':
            is_prod_machine = True
            break

    if is_prod_machine:
        tp_common.settings['test_or_prod'] = tp_common.prod
        tp_mysql.read_write_mysql['test_or_prod'] = tp_mysql.prod
        logging.info(' This is for the production machine.')
    else:
        logging.info(' This is for the test machine.')
    logging.info(' Hence, the database, ' + tp_mysql.read_write_mysql['test_or_prod']['db'] + ', in ' +
                 tp_mysql.read_write_mysql['host'] + ' is used.')

    init()  # TODO: revisit it once the radiumone_master.strategies has algo_id column !!!

    current_time_in_epoch = time.time()
    succ_count = 0
    fail_count = 0
    prod_count = 0
    idx = 0
    for arg in argv:
        if idx > 0:
            logging.info('')
            logging.info(' arg['+str(idx)+'] is ' + arg + '.')
            if '-prod' in arg:
                prod_count += 1
                continue
            if helper.does_represent_int(arg):
                logging.info(" It's a integer.")
                if is_valid_algo_id(arg):
                    logging.info(" It's a valid algorithm id.")
                    enqueue(arg, current_time_in_epoch)
                    succ_count += 1
                    logging.info(" The algorithm id, " + arg + ", had been enqueue-ed SUCCESSFULLY :)")
                else:
                    logging.info(" It's NOT a valid algorithm id.")
                    fail_count += 1
                    logging.info(" The algorithm id, " + arg + ", FAILED to be enqueue-ed :(")
            else:
                logging.info(" It's NOT a integer.")
                fail_count += 1
                logging.info(" The algorithm id, " + arg + ", FAILED to be enqueue-ed :(")
        idx += 1
    logging.info('')
    logging.info(' Out of ' + str(len(argv)-1-prod_count) + ', ' +
                 str(succ_count) + ' of them SUCCEEDED and ' +
                 str(fail_count) + ' of them FAILED.')

    end_time = time.time()
    logging.info('')
    logging.info(' ===========================================')
    logging.info(' The enqueue job ends at ' + epoch.get_current_time_up_to_second(end_time))
    logging.info(' The enqueue job elapsed time is ' + str(end_time - start_time) + ' seconds.')
    logging.info(' ===========================================')
    logging.info('')

if __name__ == '__main__':
    sys.exit(main(sys.argv))