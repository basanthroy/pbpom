__author__ = 'broy'

import MySQLdb
import logging
import pyhs2
import os

import sys
import time
import traceback

def main():

    logging.info("Main processing method")

    rw_db_connect = MySQLdb.connect('que2.dw.sc.gwallet.com',
                                'arteu',
                                'arteu1arteu',
                                'test_algo')
    rw_db_connect.autocommit(False)
    cursor = rw_db_connect.cursor()

    ro_db_connect = MySQLdb.connect('report1.dw.sc.gwallet.com',
                                    'arteu',
                                    'arteu1arteu',
                                    'radiumone_master')
    ro_db_connect.autocommit(False)
    cursor_ro = ro_db_connect.cursor()

    try:

        delete_old_data_from_current_table(cursor)
        copy_strategies_from_master_to_current(cursor, cursor_ro)
        find_and_insert_new_algos_to_queue(cursor)
        copy_current_strats_to_previous(cursor)
        # delete_old_data_from_current_table(cursor)

        rw_db_connect.commit()
    except:
        logging.error('')
        logging.error(' Exception occurred. Rollback ..')
        rw_db_connect.rollback()  # Note: rollback (i.e., release the lock) if anything goes wrong
        logging.error(traceback.format_exc())
        # TODO : Update status somewhere so other components know
    cursor.close()
    logging.info('')


def delete_old_data_from_current_table(cursor):
    try:
        delete_statement = 'delete from PB_STRATEGIES_CURRENT'
        num_rows_deleted = cursor.execute(delete_statement)
        logging.info('delete_old_data, number of rows deleted={}'.format(num_rows_deleted))
    except:
        logging.error('exception='.format(traceback.format_exc()))


def copy_strategies_from_master_to_current(cursor, cursor_ro):

    try:
        copy_strategies_statement = 'select strategy_id, baseline_bid, max_bid from STRATEGIES where bidding_engine_id = 3'
        insert_strategies_statement = 'insert into PB_STRATEGIES_CURRENT(strategy_id, baseline_bid, max_bid) VALUES (%s, %s, %s) '

        num_rows_selected = cursor_ro.execute(copy_strategies_statement)
        logging.info('copy_strategies_from_master, number of new strategies selected={}'.format(num_rows_selected))
        rows = []
        for row in cursor_ro:
            rows.append(row)

        # print 'rows={}'.format(rows)
        num_rows_inserted = cursor.executemany(insert_strategies_statement, rows)
        logging.info('copy_strategies_from_master, number of new strategies inserted={}'.format(num_rows_inserted))

    except:
        logging.error('exception={}'.format(traceback.format_exc()))


def copy_current_strats_to_previous(cursor):
    try:
        delete_previous_strats = 'DELETE FROM PB_STRATEGIES_PREVIOUS'
        copy_strats_statement = """insert into PB_STRATEGIES_PREVIOUS(strategy_id, baseline_bid, max_bid)
                                   SELECT strategy_id, baseline_bid, max_bid from PB_STRATEGIES_CURRENT
                                """
        num_rows_deleted = cursor.execute(delete_previous_strats)
        logging.info('copy_new_strats_to_old, number of rows deleted={}'.format(num_rows_deleted))
        num_rows_copied = cursor.execute(copy_strats_statement)
        logging.info('copy_new_strats_to_old, number of rows copied={}'.format(num_rows_copied))
    except:
        logging.error('exception={}'.format(traceback.format_exc()))


def find_and_insert_new_algos_to_queue(cursor):
    try:
        insert_modified_algos_statement = """
                      insert into PB_QUEUE(algo_id, create_ts, update_ts, status)
                      select distinct algos.algo_id,
                          DATE_FORMAT(NOW(),'%Y%m%d%H%i%s00') as create_ts,
                          DATE_FORMAT(NOW(),'%Y%m%d%H%i%s00') as update_ts,
                          'pending' as status
                      from (select st_alg.algo_id from PB_STRATEGIES_CURRENT curr
                      JOIN PB_STRATEGIES_PREVIOUS prev
                      on (curr.strategy_id = prev.strategy_id)
                      JOIN PB_STRATEGY_ALGO st_alg
                      on (curr.strategy_id = st_alg.strategy_id)
                      where ((curr.baseline_bid != prev.baseline_bid) or (curr.max_bid != prev.max_bid))
                      UNION ALL
                      select st_alg.algo_id from PB_STRATEGIES_CURRENT curr
                      JOIN PB_STRATEGY_ALGO st_alg
                      ON (curr.strategy_id = st_alg.strategy_id)
                      where curr.strategy_id NOT IN
                          (select strategy_id from PB_STRATEGIES_PREVIOUS)) algos;
        """
        num_algos_queued = cursor.execute(insert_modified_algos_statement)
        logging.info('find_and_insert_new_algos, num_algos_queued={}'.format(num_algos_queued))
    except:
        logging.error("find_and_insert_new_algos exception, exception={}".format(traceback.format_exc()))

if __name__ == '__main__':
    logging.basicConfig(filename='nq.log', level=logging.DEBUG)
    logging.info('Module nq invoked')
    main();