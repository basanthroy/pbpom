#!/bin/sh

if ps ax | grep -v grep | grep "deploy.py -prod" > /dev/null
then
    echo "previous deploy run for prod not done yet. exit ..."
else
    export PYTHONPATH="/opt/apps/arte_home/data_prepare/r1-dw-arte-app"
    /opt/python2.7/bin/python /opt/apps/arte_home/data_prepare/r1-dw-arte-app/application/src/main/python/com/radiumone/arte/fwk/data/prepare/job/deploy.py -prod
fi

#export PYTHONPATH="/opt/apps/arte_home/data_prepare/r1-dw-arte-app"
#/opt/python2.7/bin/python /opt/apps/arte_home/data_prepare/r1-dw-arte-app/application/src/main/python/com/radiumone/arte/fwk/data/prepare/job/deploy.py -prod