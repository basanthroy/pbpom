#export PYTHONPATH="/opt/dwradiumone/arte/app/data_prepare/r1-dw-arte-app"
#export PYTHONPATH="/home/arteu/data_prepare/r1-dw-arte-app"
#export PYTHONPATH="/home/cliu/arte_home/data_prepare/r1-dw-arte-app"
#export PYTHONPATH="/opt/apps/arte_home/data_prepare/r1-dw-arte-app"