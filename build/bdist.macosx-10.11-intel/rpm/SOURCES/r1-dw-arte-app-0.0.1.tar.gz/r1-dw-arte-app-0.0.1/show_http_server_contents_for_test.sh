curl http://jobserver2.dw.sc.gwallet.com/arte/test/
#curl -X "DELETE" http://jobserver2.dw.sc.gwallet.com/arte/test/testing.delete_me_later
#curl -X "DELETE" http://jobserver2.dw.sc.gwallet.com/arte/test/testing2.delete_me_later