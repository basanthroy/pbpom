#!/bin/sh

if ps ax | grep -v grep | grep "dequeue.py -prod" > /dev/null
then
    echo "previous dequeue run for prod not done yet. exit ..."
else
    export PYTHONPATH="/opt/dwradiumone/arte/app/data_prepare/r1-dw-arte-app"
    /opt/python2.7/bin/python /opt/dwradiumone/arte/app/data_prepare/r1-dw-arte-app/application/src/main/python/com/radiumone/arte/fwk/data/prepare/job/dequeue.py -prod
fi

#export PYTHONPATH="/opt/dwradiumone/arte/app/data_prepare/r1-dw-arte-app"
#/opt/python2.7/bin/python /opt/dwradiumone/arte/app/data_prepare/r1-dw-arte-app/application/src/main/python/com/radiumone/arte/fwk/data/prepare/job/dequeue.py -prod