from distutils.core import setup

setup(
    name = 'r1-dw-arte-app',
    version='0.0.1',
    description='ARTE app',
    author='Basanth Roy, Chu Chi Liu',
    author_email='broy@radiumone.com;cliu@radiumone.com',
    packages = [
        '.',
        'application.src.main.python.com.radiumone.arte.programmable_bidder',
        'application.src.main.python.com.radiumone.arte.programmable_bidder.config',
        'application.src.main.python.com.radiumone.arte.programmable_bidder.nqdq'
        ], # this must be the same as the name above
    url = 'ssh://git@git.dev.dw.sc.gwallet.com:7999/scm/dw/r1-dw-arte-app.git',
    #download_url = 'ssh://git@git.dev.dw.sc.gwallet.comi:7999/scm/dw/r1-dw-arte-app.git/tarball/0.1',
    keywords = ['arte', 'enqueue', 'dequeue', 'programmable_bidder'], # arbitrary keywords
    classifiers = [],
    scripts=
        ["env_var.sh",
         "show_http_server_contents_for_prod.sh",
         "show_http_server_contents_for_test.sh",
         "start_deploy_for_prod.sh",
         "start_deploy_for_test.sh",
         "start_dequeue_for_prod.sh",
         "start_dequeue_for_test.sh"
         ]
)